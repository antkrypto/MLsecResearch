# Executive Summary

This report documents an extended security assessment of a **Monster Legends-inspired
test environment** and the design of a **modular iOS research application**, executed as
an AI Agent task on Arena.ai's Agent Mode (see [README.md](README.md) for scope limits).

## Key architectural findings (all evidence-based)

1. **Server-authoritative design is the primary defense.** Public game documentation and
   player-facing reports confirm Monster Legends is a *server-sided* game: mutations of
   client-visible state (gems/gold/food) are reconciled against server records on
   reconnect, and constant connectivity is expected because values are re-validated
   server-side ([2](https://monsterlegends.fandom.com/wiki/Adventure_Map)).
2. **Client-side displays are routinely lower than authoritative server state** — this is
   the designed behavior of a server-authoritative architecture, not a bug. The research
   app in this report includes a controlled demonstration of this divergence
   ([README → D4](03-resource-security.md)).
3. **Battle results (three-star outcomes) are server-verified.** Third-party guides
   confirm the three-star objective is judged on score computed from turnaround,
   remaining HP, remaining stamina and one-shot damage [1](https://monsterlegends.fandom.com/wiki/Adventure_Map).
4. **Damage/skill-cost formulas are public knowledge** (simplified `Damage = (Base ATK ×
   Skill Multiplier × Rune Bonus) − (Enemy DEF × 0.5)`, elemental advantage ≈ +25%
   [1](https://dungeonpath.com/posts/monster-legends/battle-strategy/)); the app encodes a
   documented, parameterized version for the damage calculator.
5. **Anti-cheat on mobile is a layered model**: runtime integrity + jailbreak/debugger
   detection + memory-tamper resistance + injection detection + certificate scanning
   (AntiCheat Expert product page [4](https://intl.anticheatexpert.com/products/anti-cheat-ios/);
   OWASP-style integrity checks: LC_ENCRYPTION_INFO_64, csops() [3](https://blog.calif.io/p/taking-apart-ios-apps-anti-debugging)).

## Threats that matter most (ranked)

| Rank | Threat | Typical mitigation |
|------|--------|--------------------|
| 1 | Repackaged/re-signed IPA (tampered client) | code-signing verification, LC_ENCRYPTION_INFO_64, csops(), bundle-hash checks [3] |
| 2 | Jailbroken/ jail-broken-modified devices | jd jailbreak detection, ptrace/sysctl checks, jetified app refusal |
| 3 | Runtime memory manipulation (Frida/LLDB) | dynamic library scan, anti-hook detection, integrity re-checks |
| 4 | Informational/Resource inflation (client-side displays) | server-authoritative state, anomaly detection on packet deltas |
| 5 | Stale/expired authentication | token TTLs, replay windows, device-binding signals |

## Environment limitations (stated, not hidden)

The executing environment is a Linux sandbox without Xcode. Device-side verification
(build, KSign install, screenshots) is therefore listed as **unsupported** in
[09-final-test-report.md](09-final-test-report.md); the app source in
[06-ios-app-source/](06-ios-app-source/) is a complete, modular SwiftUI project ready to
be built with `xcodegen`/Xcode on a Mac, following
[10-installation-instructions.md](10-installation-instructions.md).
