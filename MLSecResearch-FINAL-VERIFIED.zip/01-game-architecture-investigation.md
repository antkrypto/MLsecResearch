# 1. Game Architecture Investigation

## 1.0 Scope and method

This document documents the architecture of a **Monster Legends-inspired test
environment**. Research facts are drawn from public player documentation, official game
guides and security-research references. Where the environment is synthetic
("Monster Legends-inspired"), statements describe the canonical architecture of such
games (and of real Monster Legends) rather than an observed live service — a boundary
that matters for threat-modeling fidelity. Sources are cited as `[id](url)`.

## 1.1 High-level architecture

```
┌─────────────────────────────────────────────────────────────┐
│  iOS client app (Swift/SwiftUI or Unity/Mono)               │
│  ┌─────────────┐  ┌────────────┐  ┌─────────────────────┐   │
│  │ Game logic  │  │ Resource UI│  │ Debug/Hook surface  │   │   ← Client-side state
│  └──────┬──────┘  └──────┬─────┘  └─────────┬───────────┘   │
│         └────────────────┼───────────────────┘             │
│                          ▼                                  │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ Networking / serialization (HTTP/JSON or SFS)      │   │
│  └──────────────┬──────────────────────────────────────┘   │
│                 ▼                                           │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ Anti-cheat (on-device, pre-release check)          │   │
│  └──────────────┬──────────────────────────────────────┘   │
│                 ▼                                           │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ Secure transport (TLS, request signing, tokens)    │   │
│  └─────────────────────────────────────────────────────┘   │
└──────────────────────────┬──────────────────────────────────┘
                           │  HTTPS/WebSocket
┌──────────────────────────▼──────────────────────────────────┐
│  Game backend (Gateway, Services, DB, Logging)             │
│  ┌──────────┐ ┌───────────┐ ┌──────────┐ ┌─────────────┐  │
│  │ Auth     │ │ Battle Svc│ │ Resource │ │ Analytics/  │  │
│  │ Service  │ │ +Anti-cheat│ │ Svc      │ │ Telemetry   │  │
│  └──────────┘ └───────────┘ └──────────┘ └─────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 1.2 Component-by-component analysis

For each component: **purpose → how it normally works → security risks → how
developers detect manipulation → how to protect it.**

### 1.2.1 Client-side game logic

| Aspect | Assessment |
|---|---|
| **Purpose** | Run battle simulations, render monsters, accumulate UI state (HP bars, timers). |
| **Normal behavior** | Predicts outcomes locally for snappy UX; makes requests to the server for authoritative results. |
| **Risks** | Client state (HP, resources, monster stats) can be modified in memory (Frida/LLDB/H5GG). If the server trusts it, inflating HP/resources or forcing 3-star wins is trivial. |
| **Manipulation detection (server-side)** | Re-compute battle results server-side; compare with reported result; flag anomalies (result_hash mismatch, impossible HP deltas). |
| **Protection** | Server-authoritative: every mutation (damage dealt, stars, resources) is computed on the server from server-held state. Client result fields are treated as hints only. |

> Evidence: Monster Legends is described as a *server-sided* game where the server
> "verifies the price at its end and then sends the item purchased to the account after
> confirmation" — historical exploit reports confirm earlier versions where the client
> saved state changes server-side [1](https://www.reddit.com/r/MonsterLegends/comments/6hea1i/theres_no_way_to_hack_this_game/).

### 1.2.2 Server-side game logic

| Aspect | Assessment |
|---|---|
| **Purpose** | Authoritative simulation of battles, timers, cooldowns, resource deltas, rewards. |
| **Normal behavior** | Receives signed commands (`gs_*` in SmartFoxServer-style architectures; see DeepWiki's API reference [2](https://deepwiki.com/glistermelon/mysingingmonsters-client/7.1-api-commands-reference)), re-simulates, returns state. |
| **Risks** | Input validation gaps (type confusion, overflow in damage math), desync between prediction and actual (replay attacks). |
| **Manipulation detection** | Input schema validation, idempotency keys, deterministic re-simulation from server state, anomaly scoring. |
| **Protection** | Strict schemas for all commands; server recomputes everything; log every state transition for auditing. |

### 1.2.3 Authentication systems

| Aspect | Assessment |
|---|---|
| **Purpose** | Identify the player, establish a session, bind the client to the account. |
| **Normal behavior** | Email/password or Apple/GameCenter sign-in → token (Bearer/session) → session used on subsequent requests; server-side session store with TTL. |
| **Risks** | Credential stuffing, token theft, replay of captured auth packets. |
| **Manipulation detection** | IP/geolocation anomalies, device-binding (UDID), token revocation on new device, rate limiting. |
| **Protection** | TLS everywhere, PKCE where applicable, short-lived tokens + refresh flow, device attestation, re-authentication on sensitive ops (purchase, password change). |

### 1.2.4 Resource validation

See [03-resource-security.md](03-resource-security.md).

### 1.2.5 Battle synchronization

| Aspect | Assessment |
|---|---|
| **Purpose** | Keep client and server battle state consistent; settle authoritative outcome. |
| **Normal behavior** | Turn-by-turn commands (`attack`, `skill`, `end_turn`); server confirms each; final `battle_result` message from server. |
| **Risks** | Client state divergence, skipped turns, timeouts exploited for extra turns. |
| **Manipulation detection** | Turn counter must be monotonically increasing; server-side time budget per turn; any out-of-order/gap → reject. |
| **Protection** | Server owns the clock; client sends commands, server returns authoritative event streams; any client-reported "did damage X" is ignored — damage recomputed from server HP. |

### 1.2.6 Monster-stat validation

| Aspect | Assessment |
|---|---|
| **Purpose** | Ensure monster HP/ATK/DEF/speed values are real and consistent with the server catalog. |
| **Normal behavior** | Server returns `monster` objects with base stats + upgrades; client renders derived stats. |
| **Risks** | Client displays inflated stats; client believes enemy stats (affecting damage calc shown). |
| **Manipulation detection** | Cross-checks: `total_atk` must equal base + runes + upgrades (hash-verified), cross-version consistency. |
| **Protection** | All stats derivable from server catalog; client displays read-only; terminal stat formulas server-computed and signed. |

### 1.2.7 Turn-based combat architecture

- **Action queue:** each turn produces an ordered action list; server validates legality (can the monster attack? is skill off cooldown? is the monster alive?).
- **Timers/cooldowns:** stored as absolute server timestamps (e.g., `skill_unlock_at = server_now + cooldown_ms`); client displays are derived, not authoritative.
- **Turn scheduling:** server-driven; client requests `next_turn` when ready.

### 1.2.8 Cooldown and timer systems

- **Cooldowns:** represent on the server (`unlock_time`), enforced on skill use; re-requests before unlock rejected.
- **Timers:** e.g., the Adventure Map stamina recharge (~1 point per 10 minutes, max 10 — see below). [1](https://monsterlegends.fandom.com/wiki/Adventure_Map). Client timers must re-sync on reconnect; server value is source of truth.

> Research note: Public guides confirm stamina/stamina-recharge behavior on the Adventure
> Map, including 3 stars per battle earned based on "how quickly the enemies are
> defeated, how much life the player's monsters have remaining, how much stamina they
> have remaining, whether enemies were defeated in one shot" [1](https://monsterlegends.fandom.com/wiki/Adventure_Map).

### 1.2.9 Purchase validation

See [03-resource-security.md](03-resource-security.md) — IAP receipt validation.

## 1.3 Cross-cutting concerns

### 1.3.1 Application integrity checks (high-level)

Common patterns (referenced throughout this report): `LC_ENCRYPTION_INFO_64` scan,
`csops()` entitlements check, bundle-ID/version consistency, MD5/CRC of key resources,
debugger detection. See [04-anti-cheat-application-security.md](04-anti-cheat-application-security.md).

### 1.3.2 Logging and audit

- Structured event log per command (`command_id`, `player_id`, `result`, `latency_ms`).
- Anti-replay: monotonic `sequence_number` + HMAC-signed command bodies (see [05](05-security-findings-and-threat-models.md)).

## 1.4 Research artifacts index

| Artifact | Location |
|---|---|
| Battle system security research | [02-battle-system-security-research.md](02-battle-system-security-research.md) |
| Resource security | [03-resource-security.md](03-resource-security.md) |
| Anti-cheat & application security | [04-anti-cheat-application-security.md](04-anti-cheat-application-security.md) |
| Findings & threat models | [05-security-findings-and-threat-models.md](05-security-findings-and-threat-models.md) |
| iOS research application source | [06-ios-app-source/](06-ios-app-source/) |
