# 2. Battle System Security Research

Research of the battle mechanics of a Monster Legends-inspired test environment in a
controlled test context: objective tracking, victory validation, star calculation,
server-side verification, and detection of manipulated results.

## 2.1 Automatic Three-Star System

### 2.1.1 Purpose and normal behavior

Players fight nodes on the Adventure Map and earn 1–3 stars per battle. Stars are
awarded based on a **score** derived from: speed of victory (enemies defeated quickly),
remaining player HP, remaining stamina, and whether enemies were defeated in one shot.
The first star grants basic rewards + XP; stars 2–3 unlock roulette spins.
[1](https://monsterlegends.fandom.com/wiki/Adventure_Map)

### 2.1.2 Star calculation (canonical model)

A server-authoritative scoring model must include at minimum:

```
score = w_time * (time_budget - elapsed_ms)
      + w_hp   * (remaining_player_hp_pct)
      + w_stam * (remaining_stamina)
      + w_shot * (one_shot_kills)
stars = clamp(floor(score / thresholds[0..3]), 1..3)
```

The score is computed **from server state**, not client-reported numbers.

### 2.1.3 Security analysis

| Threat | Effect if client-controlled |
|---|---|
| Force 3 stars | Rewards inflation, tournament/leaderboard abuse |
| Fabricate one-shot kills | Violates "damage floor" logic; can't be undone |
| Claim more HP remaining than possible | Bypasses time-based scoring thresholds |

### 2.1.4 Victim detection (server-side)

Server detects manipulation when:
- Reported `stars` > stars recomputed from server state within tolerance ±1.
- HP-remaining claims exceed state recomputed from the server's damage ledger.
- Faster-than-possible turn timing (see [02.3](#23-turn-based-combat-architecture)).

### 2.1.5 Protection

- Server recomputes stars on `battle_end`; client `stars` field is ignored.
- Reproducible scoring seed = server timestamp + player id (hash chain); stored with the result for audit.
- Emit `stars_discrepancy` telemetry event when client/server stars differ (see [02.1.4](#214-server-side-detection)).

## 2.2 Skill Cost (Energy/Mana)

### 2.2.1 Purpose and normal behavior

Skills consume **energy/mana** and have cooldowns ("Skills use mana / AG to cast", skills
are upgradable after level 400) [4](https://muonlinefanz.com/guide/systems/combat-mechanics/). Skill-cost calculations include base cost, upgrades, and resource state.

### 2.2.2 Client/server validation

- Client displays "energy remaining"; the server enforces `can_use_skill`:
  `current_energy >= skill.energy_cost` and `now >= skill.unlock_time`.
- Energy consumed as `energy -= energy_cost` on the **server** at cast time.

### 2.2.3 Detection of inconsistent states

Server rejects when:
- Negative energy after cast (race with parallel battle).
- Skill used while `unlock_time > now` (cooldown bypass).
- Energy changed without a `skill_cast` command (replay or direct mutation).

### 2.2.4 Protection

All energy mutations occur in the server's single battle state machine; commands are
replayed against server state with `sequence_number` monotonicity enforcement;
`energy_negative` anomalies are logged.

## 2.3 Damage System

### 2.3.1 Damage formulas

From public battle strategy research (simplified canonical formula):

```
Damage = (Base ATK × Skill Multiplier × Rune Bonus) − (Enemy DEF × 0.5)
```

with elemental advantage ≈ +25% / disadvantage ≈ −25%
[1](https://dungeonpath.com/posts/monster-legends/battle-strategy/).

Canonical variants commonly include: `crit = 1.5× base` (Critical DMG scales with damage),
`excellent = crit × 1.1`, defense reduction, and damage-over-time.

### 2.3.2 Critical-hit & excellent-damage calculations

- Crit probability/threshold per monster stats + crit runes (public guides).
- Excellent damage: "Excellent DMG = Critical DMG × 1.1"
  [4](https://muonlinefanz.com/guide/systems/combat-mechanics/).

### 2.3.3 Server-authoritative combat

Damage is computed **on the server** from:
1. Attacker's terminal ATK (base + runes + items + buffs),
2. Skill multiplier,
3. Defender's terminal DEF,
4. Element relation (attacker element vs defender).

The client-visible HP delta is a confirmation of the server's result — never the input.

### 2.3.4 Detection of damage inconsistencies

Server validates each `attack` command:
- `attacker_alive` and target in range.
- `attacker_energy >= skill.energy_cost`.
- Damage ledger (server) equals recomputed value within a tolerance band; any
  mismatch > tolerance → `damage_mismatch` telemetry + reject the command.

### 2.3.5 Protection

Server stores `hp_ledger` per battle; after each command, re-simulates; `hp` in any
client state or result is derived and ignored.

## 2.4 Enemy AI

### 2.4.1 AI decision-making

Player-facing guides describe enemy behavior: turn order (speed), attack selection,
stall options, and special "stalling" mechanics (e.g., "cooldowns activated, then
Voltaik for one-shot kills") [3](https://www.reddit.com/r/MonsterLegends/comments/5uuu0t/how_to_make_3_stars_in_adventure_map/). Canonical AI:
- Turn order determined by base + rune speed; tie-break by monster id.
- Enemy action priority: attack closest target; use skill if off cooldown and beneficial.

### 2.4.2 Turn scheduling

Server schedules turns by speed; on connect the server replays the recorded turn order
and validates that the recorded sequence matches a re-simulation (same actions, same
results). Any divergence → `turn_sequence_mismatch` and recovery via replay.

### 2.4.3 Enemy action validation

Server validates enemy actions (attack, skill) in the same way as player actions — no
trust in client-reported "enemy did X".

### 2.4.4 Detection of invalid battle states

- HP below 0 or above max → reject; HP changes without an event → `state_anomaly`.
- A monster attacked after it was killed → reject (idle-player bug detection).

## 2.5 Security Findings Summary

| Finding | Severity (per [05](05-security-findings-and-threat-models.md)) | Status |
|---|---|---|
| F-1: Stars trust client-reported battle outcome | High | Mitigated: server recomputes; reports telemetry |
| F-2: Energy/cooldown bypass on client | High | Mitigated: server-side enforcement |
| F-3: Damage mismatch via modified client | Medium-High | Mitigated: server recomputes; ledger |
| F-4: HP "display inflation" (client-only) | Low | Mitigated: server state is truth; client displays server state |

## 2.6 Research artifacts

- [02.7 Controlled demonstration: client display vs server record](03-resource-security.md#23-controlled-demonstration-client-display-differs-from-server-record)
