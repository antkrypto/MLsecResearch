# 3. Resource Security

Research of resources (Gems, Gold, Food, IAPs, costs) and how secure games prevent
unauthorized balance changes. Includes a **controlled demonstration** showing how
client-side resource displays can differ from authoritative server records.

## 3.1 Resource Catalog

| Resource | Purpose in game | Typical source |
|---|---|---|
| Gems | Cosmetics, boosts, "unlimited gems" popular via MOD APKs | IAP, VIP passes |
| Gold | Primary economy, team-up/upgrade costs | Adventure Map |
| Food | Resource for breeding/feeding | Breaking grounds, quests |
| Resources (stamina/energy) | Playtime meters | Recharge over time |

## 3.2 Cost structures under test

- **Breeding/hatching costs** — monsters cost resources; public MOD APKs advertise
  "unlimited breeding/hatching" [2](https://getmodsapr.com/8642-monster-legends-mod-apk/).
- **Upgrade costs** — generic resource math in game formulas [4](https://muonlinefanz.com/guide/systems/combat-mechanics/).

## 3.3 How secure games prevent unauthorized balance changes

Defensive mechanisms (canonical + observed references):

1. **Server-authoritative balances** — player balances live server-side; every change
   is a server mutation tied to a validated cause (quest reward, battle win, IAP receipt).
2. **Receipt validation** — IAP receipts are validated server-side; money goes through
   Apple/Google. Re-signing, tampering or self-reports of purchase are rejected
   (references: onGuardSquare-style [5](https://guardsquare.com/blog/cheating-easy-how-prevent-mobile-game-memory-tampering); SETDiff [2](https://www.reddit.com/r/MonsterLegends/comments/6hea1i/theres_no_way_to_hack_this_game/)).
3. **Anomaly detection** — telemetry flags sudden balance jumps not tied to recent
   server events (quests/rewards). Combined with:
4. **Jitter tolerance + golden paths** — server allows only transitions on validated paths; deviations alert moderation.
5. **Checksums/signed state** — `client_balance_hash` derived from server balance, returned with every `get_player_state` response; a mismatch is a reconnect trigger.

## 3.4 Security findings (initial)

| Finding | Detail | Risk |
|---|---|---|
| **F-5: MOD APKs persist by being offline** | Public MOD APBs (v20.4.5, "Always win 3 stars", "unlimited money/gems/menu") [2](https://getmodsapr.com/8642-monster-legends-mod-apm/) target offline play | If the server doesn't check, these become public methods of progress loss (do not test against real servers) |
| **F-6: Connectivity requirement** | Server re-validates on reconnect (historically exploitable versions) [1](https://www.reddit.com/r/MonsterLegends/comments/6hea1i/theres_no_way_to_hack_this_game/) | Server-side anomalies detect persistent imbalances |

## 3.5 Controlled demonstration: client display vs server record

**Demonstration plan** (designed for an authorized test environment; the actual
execution in this environment is limited by [README](README.md) — not run here):

1. **Setup**: test server with a player, balance `gems = 1000`.
2. **Client display**: app shows 999 gems on screen.
3. **Client mutation attempt (simulated)**: modifies the *displayed* value to 12345.
4. **Server check**: query `get_player_state` — server reports the actual balance (e.g., `1000 + N`).
5. **Conclusion**: displayed value ≠ authoritative balance. Divergence is expected; the
   app's integrity checker reports this as a normal risk signal, not an alert.

The iOS research app contains `ResourceSimulatorView` (client-side resource ledger) and
`ResourceManagerService` (server-authoritative simulation) implementing both sides of
this demonstration.

## 3.6 Research artifacts

- [iOS app: ResourceManagerService](06-ios-app-source/MonsterLegendsResearch/Services/ResourceManagerService.swift)
