# 4. Anti-Cheat and Application Security

Research of application integrity, IPA signing, runtime integrity, jailbreak
detection, tamper detection, API authentication, request validation, replay-attack
prevention and server-side anomaly detection.

## 4.1 Application Integrity (technical explanation)

**Purpose:** Verify the running app is the app the developer built, unmodified.

**Normal behavior:** At launch and periodically, the app computes hashes of key
resources and reads OS-level signing metadata:
- `LC_ENCRYPTION_INFO_64` — Mach-O load command indicating whether the app is encrypted
  (App Store builds) — detects repackaging.
- `csops(CS_OPS_ENTITLEMENTS_BLOB)` — returns the app's entitlements; unexpected
  entitlements indicate tampering.
- Bundle-ID, app version, device model string consistency.

**Threat model:** Repackaged/re-signed IPA (e.g., with a self-signed or shared
certificate); post-install modification.

**Defense (per [3](https://blog.calif.io/p/taking-apart-ios-apps-anti-debugging)):**
```swift
// ApplicationIntegrityService.verify()
1. Hash app bundle resources with CRC32/MD5 (LC_ENCRYPTION_INFO_64 check)
2. Verify code signature via csops()
3. If mismatch → policy (deny features / log to telemetry)
```

**Safe testing procedure:** Integrity checks should run at launch and on first launch
after update; test matrix below in [02.6](02-battle-system-security-research.md).

## 4.2 IPA Signing & Code-Signing Verification

### 4.2.1 Mechanics (per [5](https://ioscodesigning.io/), [1](https://builds.io/blog/technologies/ios-technologies/ksign-ios/))

Every iOS app must be signed by Apple before running on a device:

- **Identity:** Apple Developer Program membership → **certificate** (`.p12`)
  + **provisioning profile** (`.mobileprovision`) listing the app ID, certificates,
  and device UDIDs. Development vs. distribution variants exist.
- **Signing steps:** `codesign` (executable + resources), `ipatool` (packaging),
  verification via `codesign -v`, `otool`, `plutil`.

### 4.2.2 Validation (per [3](https://blog.calif.io/p/taking-apart-ios-apps-anti-debugging))

- `codesign -dvv` → must show Apple Developer ID / team.
- `otool -l` → check `LC_ENCRYPTION_INFO_64` present for App Store builds.
- `codesign -d` / entitlements consistency: compare entitlements to provisioning profile.

**Requirement for research app:** "An IPA suitable for legitimate KSign signing" — signed
with a real development certificate + matching provisioning profile; see
[10-installation-instructions.md](10-installation-instructions.md) and
[09-final-test-report.md](09-final-test-report.md) (install test row).

## 4.3 Runtime Integrity

**Purpose:** Detect live code injection, function hooking, or symbol replacement.

**Normal behavior:** On launch, enumerate loaded Mach-O images, compare against known
good set; re-check at intervals or on trigger (e.g., after player wins, to detect hooks
that changed outcomes).

**Threat model:** Frida attach, LLDB attach, function hooking (fishhook, Substrate),
symbol replacement.

**Defense:** dynamic-library scan (`DL_INFO` names of loaded dylibs, compare to allowlist),
hook detection via breakpoint pattern analysis, integrity re-check on battle result.

**Safe testing (see [08-test-plan.md](08-test-plan.md)):** inject a benign Frida session
on a test device and confirm the app raises `injection_detected` telemetry and refuses to
run sensitive flows.

## 4.4 Jailbreak Detection

**Purpose:** Detect modified devices (weakens security posture: AMFI bypass).

**Canonical signals** (per [5](https://trepo.tuni.fi/bitstream/handle/10024/228571/DongChenshuo.pdf?sequence=2)):
- Filesystem paths (e.g., `/usr/bin/cydia`, `/Library/MobileSubstrate`).
- Presence of `fresistence`/tweak markers, `Call%p%w` patterns (framework_hooks).
- Process spawn anomalies, `dyld_info` differences.

**Product reference:** AntiCheat Expert jailbreak detection feature `jd` [4](https://intl.anticheatexpert.com/products/anti-cheat-ios/).

**Defense:** policy table — strong restriction on jailbroken devices; log with
`device_risk_level` telemetry event.

## 4.5 Tamper Detection

**Purpose:** Detect if app state/files were modified after install.

**Defense examples:**
- Bundle hash chain stored server-side; on connect, client sends `bundle_hash`, server
  compares with stored; mismatch → re-attestation.
- `CRC32`/`MD5` re-computation on each launch (see [4.1](#41-application-integrity-technical-explanation)).

## 4.6 API Authentication

**Purpose:** Secure server↔client calls; ensure the right player talks to the server.

**Defense:**
- mTLS or TLS with client certs for sensitive flows.
- Session tokens: JWT/OAuth-style, short TTL, refresh flow.
- `device_fingerprint` binding (UDID + device model + OS version hash) — mismatch → re-login.

## 4.7 Request Validation

**Purpose:** Server must treat every client request as hostile.

**Defense:**
- Strict JSON schema (type/range checks) for all commands.
- `sequence_number` monotonicity + HMAC signature over commands (see
  [05](05-security-findings-and-threat-models.md#hmac-signed-commands)).

## 4.8 Replay-Attack Prevention

**Purpose:** Prevent captured requests from being re-sent.

**Defense:**
1. `sequence_number` per command, stored server-side; replayed → `replay_detected` telemetry.
2. Time-window + nonce: server rejects commands outside a ±30s window or with
   duplicate nonces (see [05](05-security-findings-and-threat-models.md#nonce-tracking)).

## 4.9 Server-Side Anomaly Detection

**Purpose:** Detect behavior the server doesn't expect, even from authentic clients.

**Defense:**
- Z-score scoring on resource deltas over time windows; threshold → `anomaly_score` telemetry.
- Log and alert on: negative balances (`balance_negative`), impossible turns
  (`turn_sequence_mismatch`), damage mismatches (`damage_mismatch`), stars discrepancies.
- Per-player anomaly thresholds; tiered response (warning → temporary restriction → ban,
  per AntiCheat Expert feature `asa` safety anti-peel interface [4](https://intl.anticheatexpert.com/products/anti-cheat-ios/)).

## 4.10 Summary Table (technical explanation + threat model + defense + test result)

| Mechanism | Threat model | Defense | Example test result (safe to perform) |
|---|---|---|---|
| Code-signing verification | Repackaged IPA | `csops`, `otool -l` | See [09](09-final-test-report.md) security rows |
| Jailbreak detection | Modified devices | Path/framework checks | [08.2](08-test-plan.md) |
| Runtime integrity | Injection (Frida) | dylib scan | [08.3](08-test-plan.md) |
| Replay prevention | Captured requests | Nonce + sequence | [08.4](08-test-plan.md) |
| Anomaly detection | Unauthorized state change | Z-score scoring | [08.6](08-test-plan.md) |

## 4.11 Research artifacts

- [05.5 Anomaly scoring spec](05-security-findings-and-threat-models.md#anomaly-scoring-spec)
- [08-test-plan.md](08-test-plan.md) — full security test matrix |
