# 5. Security Findings & Threat Models

Security findings (ranked), threat models, vulnerability classifications, and
recommended fixes. This document classifies findings using the model in
[4.10](04-anti-cheat-application-security.md).

## 5.1 Finding Register

| ID | Title | Class | Severity | Status | Affected area |
|----|-------|-------|----------|--------|---------------|
| F-1 | Stars trust client-reported outcome | Integrity | High | Mitigated server-side; telemetry added | Battle |
| F-2 | Energy/cooldown bypass client-side | Integrity | High | Server enforcement; re-checks | Battle |
| F-3 | Damage mismatch via modified client | Integrity | Medium-High | Server recomputes + ledger | Damage |
| F-4 | HP "display inflation" | Display | Low | Client displays server state | Resources |
| F-5 | MOD APKs play offline (no reconnect) | Policy | Medium | Server re-validation on connect | Resources |
| F-6 | Bundle integrity hash client-signed | Integrity | Medium | Server stores hash; conn check | App integrity |
| F-7 | API lacks mTLS on sensitive endpoints | Network | High | Add client certs | API auth |
| F-8 | No replay protection on auth endpoint | Replay | High | Nonce + TTL | API auth |
| F-9 | Time-based scoring uses client-reported turns | Integrity | Medium | Server timing budgets | Three-star |

Classes: Integrity (state tampering), Display (misleading UI), Policy (user restriction),
Network (transport security), Replay (duplicate execution).

## 5.2 HMAC-Signed Commands (replay defense, server design)

```
command = {
  "command_id": "c-3f2a…",
  "player_id": "p-123",
  "sequence_number": 442,
  "created_at": "2026-11-24T19:10:05Z",
  "payload": {"action": "skill", "skill_id": "bolt-of-lightning"},
  "hmac": "sha256(body + secret_key)"
}
```

Server checks: signature valid, `sequence_number > last_seen`, monotonic per player.

## 5.3 Nonce Tracking (replay prevention)

Server stores `(player_id, nonce, created_at)` for last N=1024 commands; duplicates
within a 5-minute window → `replay_detected` telemetry and reject. Combined with
`sequence_number` monotonicity.

## 5.4 Anomaly Scoring Spec

Z-score over a 60-second rolling window per player:

```
z = (x - μ_player) / σ_player
anomaly if z > 3.5 → 'anomaly_score' event (warning)
z > 5.0           → 'anomaly_score' event (restrict, not permanent)
z > 8.0           → 'anomaly_score' event + review flag
```

Unblock on verified natural growth (game over, quest rewards consistent with activity).

## 5.5 Threat Models by Component

See [01](01-game-architecture-investigation.md) for component threat models; summary here:

- **Client-side logic:** runs with user privileges; treat as untrusted (client-side).
- **Network transport:** passive observers, MITM, replay, injection at gateway.
- **Server services:** internal trust — but treat all input as hostile (defense in depth).
- **Device (iOS):** jailbreak, sandbox escape, repackaging, memory injection.

## 5.6 Recommended Security Fixes (ranked by severity)

1. **Server-authoritative state** for stars, HP, resources (recompute on `battle_end`). [F-1, F-4]
2. **IAP receipt validation** server-side before granting items. [F-2]
3. **Add client certs / mTLS** for purchase and account-critical endpoints. [F-7]
4. **Replay protection** on auth/balance endpoints. [F-8]
5. **Integrity enforcement** via `csops` + hash chain + reconnect re-attestation. [F-6]
6. **Type/range validation + limits** on damage/skill math to prevent overflow. [F-3]
7. **Anomaly scoring** with severity tiers. [F-9]

## 5.7 Test matrix → findings map

| Test (see [08](08-test-plan.md)) | Expected | Finding link |
|---|---|---|
| Invalid resource changes rejected | Yes | — |
| Invalid battle results rejected | Yes | F-1 mitigated |
| Modified client data ignored | Yes | F-4 display-only |
| Expired auth → reject | Yes | F-8 |
| Replayed request rejected | Yes | F-8 |
