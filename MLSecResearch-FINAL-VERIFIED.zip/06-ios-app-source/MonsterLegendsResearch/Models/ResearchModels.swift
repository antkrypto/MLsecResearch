import Foundation

// MARK: - Element

/// Monster elements (canonical Monster Legends elements).
enum Element: String, CaseIterable, Identifiable {
    case fire, water, earth, wind, light, dark

    var id: String { rawValue }
}

// MARK: - Monster

/// Monster data used by the simulator (server catalog model).
struct Monster: Identifiable, Codable, Hashable {
    let id: String
    let name: String
    let element: Element
    let baseATK: Double
    let baseDEF: Double
    let baseHP: Double
    let baseSpeed: Double
    let baseSD: Double

    /// Terminal stats for the current player (server-computed).
    func terminalATK() -> Double { baseATK }
    func terminalDEF() -> Double { baseDEF }

    static let samples: [Monster] = [
        Monster(id: "m-01", name: "Barbatos", element: .fire, baseATK: 2400, baseDEF: 1400,
                baseHP: 3500, baseSpeed: 300, baseSD: 900),
        Monster(id: "m-02", name: "Waterybaal", element: .water, baseATK: 2200, baseDEF: 2100,
                baseHP: 3200, baseSpeed: 280, baseSD: 850),
        Monster(id: "m-03", name: "Gargoyle", element: .earth, baseATK: 2600, baseDEF: 1300,
                baseHP: 2900, baseSpeed: 260, baseSD: 950),
        Monster(id: "m-04", name: "Terra-wind", element: .wind, baseATK: 2000, baseDEF: 1600,
                baseHP: 3800, baseSpeed: 340, baseSD: 1000),
        Monster(id: "m-05", name: "Wany Machine", element: .earth, baseATK: 2300, baseDEF: 1800,
                baseHP: 3100, baseSpeed: 320, baseSD: 920),
    ]
}

// MARK: - Skill

/// Skill data used by the damage/skill-cost calculators.
struct Skill: Identifiable, Codable, Hashable {
    let id: String
    let name: String
    let energyCost: Double
    let cooldownMs: Double
    let multiplier: Double
    let critChance: Double
    let rangeMeters: Double

    static let samples: [Skill] = [
        Skill(id: "s-01", name: "Bolt of Lightning", energyCost: 8, cooldownMs: 12000,
              multiplier: 3.2, critChance: 0.08, rangeMeters: 5),
        Skill(id: "s-02", name: "Inferno vegetables", energyCost: 12, cooldownMs: 18000,
              multiplier: 4.5, critChance: 0.12, rangeMeters: 4.5),
        Skill(id: "s-03", name: "Spike of Death", energyCost: 15, cooldownMs: 20000,
              multiplier: 5.5, critChance: 0.06, rangeMeters: 4),
    ]
}

// MARK: - PlayerStats

/// Server-authoritative player state (used by ResourceSimulator and GameEngine).
struct PlayerStats: Codable, Hashable {
    var gems: Int = 1000
    var gold: Int = 0
    var food: Int = 0
    var energy: Double = 0
    var maxEnergy: Double = 10
    var playerId: String = "p-test-01"

    var clientDisplayBalance: Int {
        // Intentionally derived display value — will differ from `gems` in the demo.
        gems
    }
}

// MARK: - BattleResult

/// Result of a simulated/validated battle.
struct BattleResult: Identifiable, Codable, Hashable {
    let id: UUID
    let stars: Int
    let won: Bool
    let hpRemaining: Double
    let damageDealt: Double
    let elapsedMs: Double
    let serverComputed: Bool

    var timeBonusMs: Double { max(0, 1000 - elapsedMs) }
    var oneShotBonus: Double { 0 }
}

// MARK: - SimSettings

/// Configurable simulator settings (research: [08-test-plan.md](../08-test-plan.md)).
struct SimSettings: Codable, Hashable, Identifiable {
    let id: String
    var showModMenu: Bool = true
    var telemetryEnabled: Bool = true
    var autoRunOnLaunch: Bool = true

    static let presets: [SimSettings] = [
        SimSettings(id: "default", showModMenu: true, telemetryEnabled: true, autoRunOnLaunch: true),
        SimSettings(id: "silent", showModMenu: false, telemetryEnabled: false, autoRunOnLaunch: false),
    ]

    static var sample: SimSettings { presets[0] }
}

// MARK: - TestRecord

/// One row of the test-result history shown by TestHistoryView.
struct TestRecord: Identifiable, Codable, Hashable {
    let id: UUID
    let feature: String
    let name: String
    let status: TestStatus
    let executedAt: Date
    let notes: String?
    var environment: String = "ios-simulator"

    enum StatusFilter: String, CaseIterable {
        case all, passed, failed, notRun
    }
}

// MARK: - TestStatus

/// Status of a feature test.
enum TestStatus: String, CaseIterable, Codable, Identifiable, Hashable {
    case passed, failed, notRun

    var id: String { rawValue }
}

// MARK: - Module error

enum ResearchError: LocalizedError, Hashable {
    case validationFailed(String)
    case integrityFailure(String)
    case invalidArgument(String)

    var errorDescription: String? {
        switch self {
        case .validationFailed(let m): return "validation failed: \(m)"
        case .integrityFailure(let m): return "integrity failure: \(m)"
        case .invalidArgument(let m): return "invalid argument: \(m)"
        }
    }
}
