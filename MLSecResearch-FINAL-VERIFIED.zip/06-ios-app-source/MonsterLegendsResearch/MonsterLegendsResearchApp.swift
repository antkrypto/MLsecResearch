import SwiftUI

@main
struct MonsterLegendsResearchApp: App {
    @State private var historySheet: TestRecord?   // valid .sheet(item:)

    var body: some Scene {
        WindowGroup {
            TabView {
                NavigationStack { BattleSystemSimulatorView() }
                    .tabItem { Label("Battle Simulator", systemImage: "crossed.swords") }
                NavigationStack { MonsterDatabaseView() }
                    .tabItem { Label("Monster DB", systemImage: "book") }
                NavigationStack { DamageCalculatorView() }
                    .tabItem { Label("Damage", systemImage: "bolt.fill") }
                NavigationStack { ResourceSimulatorView() }
                    .tabItem { Label("Resources", systemImage: "giftcard") }
                NavigationStack { TimerSimulatorView() }
                    .tabItem { Label("Timers", systemImage: "stopwatch") }
                NavigationStack { SecurityDashboardView() }
                    .tabItem { Label("Security", systemImage: "shield") }
                NavigationStack { IntegrityCheckerView() }
                    .tabItem { Label("Integrity", systemImage: "checklist") }
                NavigationStack { APISecurityTestView() }
                    .tabItem { Label("API Security", systemImage: "key") }
                NavigationStack { TestHistoryView() }
                    .tabItem { Label("History", systemImage: "list.bullet") }
                NavigationStack { SettingsView() }
                    .tabItem { Label("Settings", systemImage: "gear") }
            }
            .sheet(item: $historySheet) { _ in TestHistoryView() }
            .onAppear {
                // Record the launch sweep into history.
                let out = TestRunnerService.shared.runFeatureSweep(
                    settings: SettingsView().settings)
                for r in out {
                    TestRunnerService.shared.record(feature: r.feature, name: r.name, status: r.status)
                }
            }
            .overlay { FloatingModMenuView() }
            // Professional dark theme + neon-green accents (DesignTokens.swift).
            .preferredColorScheme(.dark)
            .accentColor(Design.neonGreen)
        }
    }
}
