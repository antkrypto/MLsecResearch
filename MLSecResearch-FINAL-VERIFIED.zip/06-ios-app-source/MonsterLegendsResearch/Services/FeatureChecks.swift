import Foundation

/// Real, executable feature checks used by the automated sweep.
/// Each check performs actual logic and returns true/false — no hardcoded
/// "success" values (research fidelity: see [08-test-plan.md](../../08-test-plan.md)).
enum FeatureChecks {
    // MARK: Battle

    /// Three-star simulator: serverComputed result with stars in 0...3.
    static func checkThreeStar() -> Bool {
        let r = GameEngine.shared.simulateBattle(attacker: Monster.samples[0],
                                                 defender: Monster.samples[1],
                                                 skill: Skill.samples[0])
        return r.serverComputed && r.stars >= 0 && r.stars <= 3
    }

    /// No-skill-cost simulator: produces a positive damage figure.
    static func checkNoSkillCost() -> Bool {
        let r = GameEngine.shared.simulateNoSkillCostBattle(attacker: Monster.samples[0],
                                                            defender: Monster.samples[2])
        return r.damageDealt > 0
    }

    /// One-hit simulator: enemy HP goes to 0.
    static func checkOneHit() -> Bool {
        let r = GameEngine.shared.simulateBattle(attacker: Monster.samples[2],
                                                 defender: Monster.samples[1],
                                                 skill: Skill.samples[2],
                                                 mode: "oneHit")
        return r.hpRemaining == 0
    }

    /// Disabled-AI simulator: damage ledger non-zero, server-computed.
    static func checkDisableAI() -> Bool {
        let r = GameEngine.shared.simulateBattle(attacker: Monster.samples[3],
                                                 defender: Monster.samples[1],
                                                 skill: Skill.samples[1],
                                                 mode: "disabledAI")
        return r.damageDealt > 0 && r.serverComputed
    }

    // MARK: Database

    static func checkMonsterDB() -> Bool { !Monster.samples.isEmpty }

    // MARK: Damage

    static func checkDamageCalculator() -> Bool {
        let d = GameEngine.shared.damage(attacker: Monster.samples[0],
                                         skill: Skill.samples[0],
                                         defender: Monster.samples[1])
        return d > 0 && (try? GameEngine.shared.validateDamage(value: d)) != nil
    }

    // MARK: Resources

    /// Server rejects negative balance changes.
    static func checkResourceManager() -> Bool {
        !ResourceManagerService.shared.validateBalanceChange(delta: -1).allowed
    }

    /// Controlled demonstration: client display differs from server record.
    static func checkResourceDemoDiverges() -> Bool {
        let (client, server) = ResourceManagerService.shared.demonstrationSnapshot()
        return client != server
    }

    // MARK: Timers

    static func checkTimerManager() -> Bool {
        TimerService.shared.setCooldown(duration: 12)
        return TimerService.shared.cooldownRemaining() > 0 && TimerService.shared.isCoolingDown()
    }

    // MARK: Floating mod menu — the view type must exist and register.
    static func checkFloatingModMenu() -> Bool { FloatingModMenuView.menuItems.count > 0 }

    // MARK: Settings persistence (real UserDefaults round-trip)

    static func checkSettingsPersist() -> Bool {
        let key = "ml.test.settings-check"
        UserDefaults.standard.set("ok", forKey: key)
        return UserDefaults.standard.string(forKey: key) == "ok"
    }

    // MARK: Security sweep — real validator behavior

    static func validateStars4Throws() -> Bool {
        do { _ = try GameEngine.shared.validateStars(value: 4); return false }
        catch { return true }
    }

    static func validateDamageNegativeThrows() -> Bool {
        do { _ = try GameEngine.shared.validateDamage(value: -1); return false }
        catch { return true }
    }

    static func rejectNegativeBalance() -> Bool {
        !ResourceManagerService.shared.validateBalanceChange(delta: -1).allowed
    }
}
