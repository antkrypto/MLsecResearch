import Foundation

/// Core of the battle-system simulator: damage calculator, skill-cost math and
/// server-authoritative three-star scoring. Mirrors research in
/// [02-battle-system-security-research.md](../../02-battle-system-security-research.md).
final class GameEngine {
    static let shared = GameEngine()
    private init() {}

    // MARK: Damage

    /// Canonical damage model (simplified public formula + element adjustment):
    /// `Damage = (Base ATK × Skill Multiplier × Rune Bonus) − (Enemy DEF × 0.5)`
    /// with elemental advantage ≈ +25% / disadvantage ≈ −25%.
    func damage(attacker: Monster, skill: Skill, defender: Monster) -> Double {
        var base = attacker.terminalATK() * skill.multiplier
        let defReduction = defender.terminalDEF() * 0.5
        var dmg = base - defReduction
        dmg = elementModifier(attacker.element, vs: defender.element) * dmg
        return max(0, dmg)
    }

    /// Server-authoritative damage variant with defense only reducing a capped fraction
    /// of DEF and optional crit (used in One-Hit simulator mode).
    func damageServer(attacker: Monster, skill: Skill, defender: Monster, crit: Bool) -> Double {
        var base = attacker.terminalATK() * skill.multiplier
        base = elementModifier(attacker.element, vs: defender.element) * base
        if crit { base *= 1.5 }
        // Server reduces DEF at 50% and never goes below 0.
        let reducedDef = defender.terminalDEF() * 0.5
        return max(0, base - reducedDef)
    }

    private func elementModifier(_ a: Element, vs d: Element) -> Double {
        if a == d { return 1.0 }
        if (a == .fire && d == .wind) || (a == .water && d == .fire)
            || (a == .earth && d == .water) || (a == .wind && d == .earth)
            || (a == .light && d == .dark) {
            return 1.25 // advantage
        }
        if (a == .wind && d == .fire) || (a == .fire && d == .water)
            || (a == .earth && d == .wind) || (a == .water && d == .earth)
            || (a == .dark && d == .light) {
            return 0.75 // disadvantage
        }
        return 1.0
    }

    // MARK: Skill cost

    /// Energy consumption for a skill use (server model): `energy -= energyCost`.
    func skillCost(skill: Skill, playersEnergy: Double, player: PlayerStats) -> Double {
        // No-Skill-Cost simulator mode (see SimSettings) consumes 0.
        // Research: [02.2 Skill Cost](../../02-battle-system-security-research.md#22-skill-cost-energymana).
        return 0
    }

    func canUseSkill(skill: Skill, playersEnergy: Double, cooldownUntil: Date, now: Date) -> Bool {
        guard playersEnergy >= skill.energyCost else { return false }
        guard now >= cooldownUntil else { return false }
        return true
    }

    // MARK: Three-Star scoring

    /// Stars from the score, using thresholds that place three stars above time budget.
    /// See [02.1](../../02-battle-system-security-research.md#21-automatic-three-star-system).
    func stars(score: Double) -> Int {
        switch score {
        case let s where s >= 450: return 3
        case let s where s >= 320: return 2
        case let s where s >= 190: return 1
        default: return 0
        }
    }

    /// Score from server state (always computed from server-held values).
    func score(elapsedMs: Double, remainingHP: Double, remainingStamina: Double, oneShotKills: Int) -> Double {
        let timeBonus = max(0, 1000 - elapsedMs)
        let hp = remainingHP
        let stamina = remainingStamina
        let oneShot = Double(oneShotKills) * 50
        return timeBonus * 0.5 + hp * 0.3 + stamina * 0.1 + oneShot
    }

    // MARK: Battle simulation

    /// Runs a small deterministic battle simulation.
    /// Modes: `normal`, `noSkillCost`, `oneHit`, `disabledAI`.
    func simulateBattle(attacker: Monster, defender: Monster,
                        skill: Skill, mode: String = "normal",
                        elapsedMs: Double = 250) -> BattleResult {
        var defenderHP = defender.baseHP
        var hpRemaining = defenderHP
        var damageDealt = 0.0
        var starred = false

        switch mode {
        case "oneHit":
            let d = damageServer(attacker: attacker, skill: skill, defender: defender, crit: true)
            damageDealt = d
            hpRemaining = max(0, defenderHP - d)
            starred = hpRemaining == 0
        case "disabledAI":
            // Enemy AI cannot respond; player finishes quickly → faster score.
            let d = damageServer(attacker: attacker, skill: skill, defender: defender, crit: false)
            damageDealt = d
            hpRemaining = max(0, defenderHP - d)
        default:
            let d = damageServer(attacker: attacker, skill: skill, defender: defender, crit: skill.critChance > 0.2)
            damageDealt = d
            hpRemaining = max(0, defenderHP - d)
        }

        let s = score(elapsedMs: elapsedMs,
                      remainingHP: hpRemaining,
                      remainingStamina: 0.2,
                      oneShotKills: starred ? 1 : 0)
        return BattleResult(id: UUID(), stars: stars(score: s), won: hpRemaining == 0,
                            hpRemaining: hpRemaining, damageDealt: damageDealt,
                            elapsedMs: elapsedMs, serverComputed: true)
    }

    // MARK: No-Skill-Cost simulator

    /// Simulates a battle where skill costs are bypassed (client-side simulation only).
    func simulateNoSkillCostBattle(attacker: Monster, defender: Monster) -> BattleResult {
        let skill = Skill(id: "s-nsc", name: "No-Cost Bolt", energyCost: 0, cooldownMs: 0,
                          multiplier: 6.0, critChance: 0.5, rangeMeters: 5)
        return simulateBattle(attacker: attacker, defender: defender, skill: skill,
                              mode: "oneHit", elapsedMs: 150)
    }

    // MARK: Invalid-state validators (server-side model)

    func validateDamage(value: Double) throws -> Double {
        guard value.isFinite, value >= 0 else { throw ResearchError.validationFailed("damage must be finite and non-negative") }
        return value
    }

    func validateStars(value: Int) throws -> Int {
        guard (0...3).contains(value) else { throw ResearchError.validationFailed("stars must be 0..3") }
        return value
    }
}
