import Foundation

/// Resource simulator. Demonstrates how client-side resource displays can differ from
/// authoritative server records (see [03-resource-security.md](../../03-resource-security.md#23-controlled-demonstration-client-display-differs-from-server-record)).
final class ResourceManagerService {
    static let shared = ResourceManagerService()
    private init() {}

    private var serverBalance = 500 // server-authoritative

    // MARK: Client display vs server state

    /// Simulates a client display mutated by a (simulated) client-side injection.
    func mutateClientDisplay() -> Int {
        let displayed = serverBalance + 12345
        return displayed
    }

    /// Server record — the authoritative value.
    func serverRecord() -> Int { serverBalance }

    // MARK: Server-authoritative mutations

    func serverGrantGems(_ amount: Int) { serverBalance += amount }
    func serverGrantGold(_ amount: Int) { serverBalance += amount }
    func serverConsumeGems(_ amount: Int) throws {
        guard serverBalance >= amount else { throw ResearchError.validationFailed("insufficient gems") }
        serverBalance -= amount
    }

    // MARK: Validation

    /// Checks a client-supplied balance change against the server.
    func validateBalanceChange(delta: Int) -> (allowed: Bool, reason: String) {
        if delta <= 0 {
            return (false, "Negative balance changes are server-rejected (anti-cheat F-3)")
        }
        if serverBalance + delta > 1_000_000 {
            return (false, "Delta exceeds anomaly threshold — server would flag telemetry (F-9)")
        }
        return (true, "allowed: delta \(delta) within tolerance")
    }

    // MARK: Controlled demonstration (as run in 03)

    /// Step 2 of the controlled demonstration: client shows 999, server holds 1000+.
    func demonstrationSnapshot() -> (client: Int, server: Int) {
        serverGrantGems(1_000) // server now 1000
        return (999, serverRecord())
    }
}
