import Foundation

/// Runs the automated feature + security tests, recording results into history.
/// Feature matrix is in [08-test-plan.md](../../08-test-plan.md) and the report table is
/// [09-final-test-report.md](../../09-final-test-report.md).
final class TestRunnerService {
    static let shared = TestRunnerService()

    private var history = TestHistoryStore()
    private let defaults = UserDefaults.standard

    private init() {}

    // MARK: Manual test invokers (used by feature views)

    func runAutomaticThreeStar() -> BattleResult { GameEngine.shared.simulateBattle(attacker: Monster.samples[0], defender: Monster.samples[1], skill: Skill.samples[0]) }
    func runNoSkillCostSim() -> BattleResult { GameEngine.shared.simulateNoSkillCostBattle(attacker: Monster.samples[0], defender: Monster.samples[2]) }
    func runOneHitSim() -> BattleResult { GameEngine.shared.simulateBattle(attacker: Monster.samples[2], defender: Monster.samples[1], skill: Skill.samples[2], mode: "oneHit") }
    func runDisableAI() -> BattleResult { GameEngine.shared.simulateBattle(attacker: Monster.samples[3], defender: Monster.samples[1], skill: Skill.samples[1], mode: "disabledAI") }

    // MARK: History

    @discardableResult
    func record(feature: String, name: String, status: TestStatus, notes: String? = nil, env: String = "ios-simulator") -> TestRecord {
        let rec = TestRecord(id: UUID(), feature: feature, name: name, status: status,
                             executedAt: Date(), notes: notes, environment: env)
        history.append(rec)
        return rec
    }

    func all() -> [TestRecord] { history.all() }

    // MARK: Automated sweep (on launch, when settings allow)

    func runFeatureSweep(settings: SimSettings) -> [TestRecord] {
        guard settings.autoRunOnLaunch else { return [] }
        var out: [TestRecord] = []
        let jobs: [(feature: String, name: String, check: () -> TestStatus)] = [
            ("Floating mod menu", "Mod menu overlay is registered and lists menuItems", { FeatureChecks.checkFloatingModMenu() ? .passed : .failed }),
            ("Automatic three-star simulator", "Three-star simulation runs; serverComputed == true", { FeatureChecks.checkThreeStar() ? .passed : .failed }),
            ("No-skill-cost simulator", "No-skill-cost simulation produces damage > 0", { FeatureChecks.checkNoSkillCost() ? .passed : .failed }),
            ("One-hit battle simulator", "One-hit simulation leaves hpRemaining == 0", { FeatureChecks.checkOneHit() ? .passed : .failed }),
            ("Disable AI simulator", "Disabled-AI simulation produces damage > 0", { FeatureChecks.checkDisableAI() ? .passed : .failed }),
            ("Monster database", "Monster catalog loads (samples non-empty)", { FeatureChecks.checkMonsterDB() ? .passed : .failed }),
            ("Damage calculator", "Damage formula returns positive value; validateDamage passes", { FeatureChecks.checkDamageCalculator() ? .passed : .failed }),
            ("Resource manager", "Server record is consistent; negative changes rejected", { FeatureChecks.checkResourceManager() && FeatureChecks.checkResourceDemoDiverges() ? .passed : .failed }),
            ("Timer manager", "Cooldown remaining > 0 while cooling down", { FeatureChecks.checkTimerManager() ? .passed : .failed }),
            ("Automation controls", "Automated sweep runs all simulator checks (real assertions)", {
                FeatureChecks.checkThreeStar() && FeatureChecks.checkNoSkillCost()
                    && FeatureChecks.checkOneHit() && FeatureChecks.checkDisableAI()
                    ? .passed : .failed
            }),
            ("Settings and configuration saving", "Settings round-trip through UserDefaults", { FeatureChecks.checkSettingsPersist() ? .passed : .failed }),
        ]
        for j in jobs {
            out.append(record(feature: j.feature, name: j.name, status: j.check()))
        }
        return out
    }

    // MARK: Security sweeps (real validators)

    func runSecuritySweep() -> [TestRecord] {
        var out: [TestRecord] = []
        let checks: [(feature: String, name: String, status: TestStatus)] = [
            ("Security", "Invalid resource changes are rejected", FeatureChecks.checkResourceManager() ? .passed : .failed),
            ("Security", "Invalid battle results are rejected", FeatureChecks.validateStars4Throws() ? .passed : .failed),
            ("Security", "Damage calculations are validated", FeatureChecks.validateDamageNegativeThrows() ? .passed : .failed),
            ("Security", "Modified client data cannot override server", FeatureChecks.rejectNegativeBalance() ? .passed : .failed),
        ]
        for c in checks {
            out.append(record(feature: c.feature, name: c.name, status: c.status))
        }
        return out
    }
}

/// Simple history store backed by UserDefaults (syncs across launches of the app).
struct TestHistoryStore {
    private let key = "MLSecResearch.testHistory"

    mutating func append(_ rec: TestRecord) {
        var items = all()
        items.append(rec)
        if let data = try? JSONEncoder().encode(items) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    func all() -> [TestRecord] {
        guard let data = UserDefaults.standard.data(forKey: key) else { return [] }
        return (try? JSONDecoder().decode([TestRecord].self, from: data)) ?? []
    }
}
