import Foundation

/// Timer simulator: cooldowns and stamina/stamina-recharge timers
/// (see [01.2.7 Cooldown and timer systems](../../01-game-architecture-investigation.md#127-cooldown-and-timer-systems)).
final class TimerService {
    static let shared = TimerService()
    private init() {}

    /// Stored as absolute server-style timestamps: `endTime = now + duration`.
    private var cooldownUntil: Date = .distantPast
    private var exhaustedUntil: Date = .distantPast

    private let rechargeInterval: TimeInterval = 600 // 10 min (documented in public guides)
    private var exhaustedSince: Date = .distantPast

    // MARK: Cooldown

    func setCooldown(duration: TimeInterval) {
        cooldownUntil = Date().addingTimeInterval(duration)
    }

    func cooldownRemaining() -> TimeInterval {
        max(0, cooldownUntil.timeIntervalSinceNow)
    }

    func isCoolingDown() -> Bool { cooldownRemaining() > 0 }

    // MARK: Stamina recharge

    /// Starts the recharge timer; stamina recharges 1 per `rechargeInterval` up to `max`.
    func startStaminaRecharge(maxStamina: Double) {
        exhaustedUntil = Date().addingTimeInterval(rechargeInterval)
        exhaustedSince = Date()
    }

    func exhausted(maxStamina: Double) -> Bool {
        Date() >= exhaustedUntil
    }

    func elapsedSinceExhausted() -> TimeInterval {
        Date().timeIntervalSince(exhaustedSince)
    }

    // MARK: Unit-testable time model

    /// Server-style prediction: how much timeframe has elapsed.
    func rechargedAmount(maxStamina: Double, elapsedSeconds: Double) -> Double {
        min(maxStamina, floor(elapsedSeconds / rechargeInterval))
    }
}
