import SwiftUI

/// Design tokens: dark theme + neon-green accent palette.
enum Design {
    // MARK: Colors

    /// Neon green accent — the app's signature color (Apple Green #00FF40-ish).
    static let neonGreen = Color(red: 0.0, green: 1.0, blue: 0.28) // #00FF47

    /// Slightly dimmer variant for body text on dark backgrounds.
    static let neonGreenDim = Color(red: 0.0, green: 0.85, blue: 0.15)

    /// Dark background core.
    static let darkBG = Color(red: 0.04, green: 0.04, blue: 0.07) // #0A0A12

    /// Slightly lighter panel/card surface.
    static let cardBG = Color(red: 0.10, green: 0.10, blue: 0.14) // #1A1A24

    /// Warning/danger orange (used by ResourceSimulatorView).
    static let dangerOrange = Color(red: 1.0, green: 0.42, blue: 0.0)

    // MARK: Fonts

    static func title(_ s: String) -> Text { Text(s).font(.largeTitle).bold().foregroundColor(.white) }
    static func body(s: String) -> Text { Text(s).font(.body).foregroundColor(Color.white.opacity(0.85)) }

    // MARK: Components

    /// Section label with neon glow.
    static func sectionTitle(_ s: String) -> Text {
        Text(s).font(.title3).bold().foregroundColor(neonGreen).shadow(color: neonGreen.opacity(0.5), radius: 3)
    }

    /// Neon-glow card for dashboards.
    static func card<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            content()
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(cardBG)
        .cornerRadius(12)
        .shadow(color: neonGreen.opacity(0.08), radius: 4)
    }
}
