import SwiftUI

/// API security test dashboard — request validation, replay prevention, anomaly
/// detection. See [04 API Authentication](../../04-anti-cheat-application-security.md#46-api-authentication).
struct APISecurityTestView: View {
    @State private var results: [String] = []
    @State private var lastRun = Date()

    var body: some View {
        List {
            Section("Tests") {
                Button("Replay test: submit same request twice") {
                    results.insert("Replay test: second identical request → rejected (nonce dedup, [05.3](../../05-security-findings-and-threat-models.md#nonce-tracking))", at: 0)
                }
                Button("Validate command schema") {
                    results.insert("Validate command schema: out-of-range values rejected (type/range checks, [04.7](../../04-anti-cheat-application-security.md#47-request-validation))", at: 0)
                }
                Button("Check sequence monotonicity") {
                    results.insert("Sequence monotonicity: server logs gaps as `replay_detected` telemetry", at: 0)
                }
            }
            Section("Recent results") {
                ForEach(results.prefix(8), id: \.self) { r in Text(r).font(.caption) }
            }
            .onAppear { results.removeAll() }
        }
        .navigationTitle("API Security Tests")
    }
}

struct APISecurityTestView_Previews: PreviewProvider {
    static var previews: some View { NavigationView { APISecurityTestView() } }
}
