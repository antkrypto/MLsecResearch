import SwiftUI

/// Automatic three-star simulator. See [02.1 Automatic Three-Star System](../../02-battle-system-security-research.md#21-automatic-three-star-system).
struct BattleSystemSimulatorView: View {
    @State private var results: [BattleResult] = []
    @State private var attacker = Monster.samples[0]
    @State private var defender = Monster.samples[1]

    var body: some View {
        List {
            Section("Attacker / Defender") {
                Picker("Attacker", selection: $attacker) {
                    ForEach(Monster.samples) { m in Text(m.name).tag(m) }
                }
                Picker("Defender", selection: $defender) {
                    ForEach(Monster.samples) { m in Text(m.name).tag(m) }
                }
            }
            Button("Simulate Three-Star Battle") {
                results.insert(GameEngine.shared.simulateBattle(
                    attacker: attacker, defender: defender, skill: Skill.samples[0]), at: 0)
            }
            .padding(.vertical, 4)

            Section("Server-Authoritative Scores") {
                ForEach(results.prefix(5), id: \.id) { r in
                    HStack {
                        Text("Stars: \(r.stars)").fontWeight(.semibold)
                        Spacer()
                        Text("HP: \(r.hpRemaining.rounded())").font(.caption)
                        Text("Damage: \(r.damageDealt.rounded())").font(.caption)
                        Text(r.serverComputed ? "Server ✓" : "Client ✗").font(.caption2)
                    }
                }
            }
        }
        .navigationTitle("Battle-System Simulator")
    }
}

struct BattleSystemSimulatorView_Previews: PreviewProvider {
    static var previews: some View { NavigationView { BattleSystemSimulatorView() } }
}
