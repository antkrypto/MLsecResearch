import SwiftUI

/// Damage calculator using the canonical Monster Legends damage model
/// (see [02.3 Damage System](../../02-battle-system-security-research.md#23-damage-system)).
struct DamageCalculatorView: View {
    @State private var attacker = Monster.samples[0]
    @State private var defender = Monster.samples[1]
    @State private var skill = Skill.samples[0]
    @State private var result: Double?

    var body: some View {
        List {
            Picker("Attacker", selection: $attacker) {
                ForEach(Monster.samples) { m in Text(m.name).tag(m) }
            }
            Picker("Defender", selection: $defender) {
                ForEach(Monster.samples) { m in Text(m.name).tag(m) }
            }
            Picker("Skill", selection: $skill) {
                ForEach(Skill.samples) { s in Text(s.name).tag(s) }
            }

            Button("Calculate Damage") { result = GameEngine.shared.damage(attacker: attacker, skill: skill, defender: defender) }
                .buttonStyle(.borderedProminent)

            if let r = result {
                Section("Result") {
                    Text("Damage: \(r.rounded())").font(.title2).fontWeight(.bold)
                    Text("Formula: (\(attacker.baseATK.rounded()) × \(skill.multiplier) × element) − \(defender.baseDEF.rounded()) × 0.5").font(.caption)
                }
            }
        }
        .navigationTitle("Damage Calculator")
    }
}

struct DamageCalculatorView_Previews: PreviewProvider {
    static var previews: some View { NavigationView { DamageCalculatorView() } }
}
