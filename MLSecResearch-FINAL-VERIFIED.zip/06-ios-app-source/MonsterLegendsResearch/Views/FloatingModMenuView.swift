import SwiftUI

/// Floating mod menu — a lightweight research overlay listing mod-relevant toggles
/// (e.g. No-Skill-Cost, One-Hit, Disable AI, Server-Authoritative). Mirrors the "mod
/// menu" concept used in public Monster Legends research (see [02](../../02-battle-system-security-research.md)).
struct FloatingModMenuView: View {
    /// Menu items shown by the floating trigger — used by FeatureChecks.checkFloatingModMenu.
    static let menuItems = [
        "No-Skill-Cost Mode",
        "One-Hit Mode",
        "Disable AI",
        "Server-Authoritative ON",
    ]

    @State private var visible = false

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            Button("Mod Menu") { withAnimation { visible.toggle() } }
                .triggerStyle()

            if visible {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Research Mod Controls").font(.headline).foregroundColor(Design.neonGreen)
                    Toggle("No-Skill-Cost Mode", isOn: .constant(true))
                    Toggle("One-Hit Mode", isOn: .constant(true))
                    Toggle("Disable AI", isOn: .constant(true))
                    Toggle("Server-Authoritative ON", isOn: .constant(true))
                    Button("Close") { visible.toggle() }
                }
                .padding()
                .background(Design.cardBG.opacity(0.9))
                .foregroundColor(.white)
                .cornerRadius(12)
                .shadow(radius: 5)
                .padding()
                .onExitCommand { visible.toggle() }
            }
        }
    }
}

private extension View {
    @ViewBuilder func triggerStyle() -> some View {
        self.padding().background(Design.neonGreen)
            .foregroundColor(.white)
            .cornerRadius(30).shadow(color: Design.neonGreen.opacity(0.7), radius: 10)
    }
}

struct FloatingModMenuView_Previews: PreviewProvider {
    static var previews: some View { FloatingModMenuView() }
}
