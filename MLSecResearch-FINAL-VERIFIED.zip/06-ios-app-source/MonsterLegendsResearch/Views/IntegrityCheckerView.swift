import SwiftUI

/// Application integrity checker — displays `IntegrityChecker.IntegrityReport`.
struct IntegrityCheckerView: View {
    @State private var report: IntegrityChecker.IntegrityReport?

    var body: some View {
        List {
            Section("Check") {
                Button("Run integrity check") { report = IntegrityChecker.shared.checkAndReport() }
                    .buttonStyle(.borderedProminent)
            }
            if let r = report {
                Section("Report") {
                    Row("Signature valid", value: "\(r.signatureValid)")
                    Row("Bundle ID match", value: "\(r.bundleIdMatch)")
                    Row("Version match", value: "\(r.versionMatch)")
                    Row("Risk level", value: "\(r.riskLevel)")
                    Row("Hash entries", value: "\(r.resourceHashes.count)")
                }
            }
        }
        .navigationTitle("Integrity Checker")
        .onAppear { report = IntegrityChecker.shared.checkAndReport() }
    }
}

struct Row: View {
    let label: String
    let value: String
    init(_ label: String, value: String) { self.label = label; self.value = value }
    var body: some View {
        HStack { Text(label).bold(); Spacer(); Text(value).font(.caption) }
    }
}

struct IntegrityCheckerView_Previews: PreviewProvider {
    static var previews: some View { NavigationView { IntegrityCheckerView() } }
}
