import SwiftUI

/// Monster database — browse the sample monster catalog.
struct MonsterDatabaseView: View {
    private let monsters = Monster.samples
    private let skills = Skill.samples

    var body: some View {
        List {
            Section("Monsters") {
                ForEach(monsters) { m in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(m.name).font(.headline)
                            Text("\(m.element.rawValue) · ATK \(m.baseATK.rounded()) · HP \(m.baseHP.rounded())")
                                .font(.caption).foregroundColor(.secondary)
                        }
                        Spacer()
                        Text(m.id).font(.caption2).foregroundColor(.secondary)
                    }
                }
            }
            Section("Skills") {
                ForEach(skills) { s in
                    HStack {
                        Text(s.name).bold()
                        Spacer()
                        Text("energy: \(s.energyCost)")
                        Text("cooldown: \(Int(s.cooldownMs/1000))s")
                    }
                }
            }
        }
        .navigationTitle("Monster Database")
    }
}

struct MonsterDatabaseView_Previews: PreviewProvider {
    static var previews: some View { NavigationView { MonsterDatabaseView() } }
}
