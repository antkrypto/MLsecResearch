import SwiftUI

/// Resource simulator — demonstrates client display vs authoritative server record
/// (see [03 Resource Security](../../03-resource-security.md#23-controlled-demonstration-client-display-differs-from-server-record)).
struct ResourceSimulatorView: View {
    @State private var clientDisplay: Int = 0
    @State private var serverRecord: Int = 0
    @State private var deltaResult: String?
    @State private var deltaInput = ""

    var body: some View {
        List {
            Section("Controlled demonstration") {
                HStack {
                    Text("Client display:")
                    Spacer()
                    Text("\(clientDisplay)").fontWeight(.bold).foregroundColor(.orange)
                }
                HStack {
                    Text("Server record:")
                    Spacer()
                    Text("\(serverRecord)").fontWeight(.bold).foregroundColor(.green)
                }
            }
            Button("Run demonstration") {
                let (c, s) = ResourceManagerService.shared.demonstrationSnapshot()
                clientDisplay = c
                serverRecord = s
            }

            Section("Balance change validation (server-authoritative)") {
                TextField("Enter proposed delta", text: $deltaInput)
                    .keyboardType(.numberPad)
                Button("Validate") {
                    guard let d = Int(deltaInput) else { deltaResult = "invalid input"; return }
                    let v = ResourceManagerService.shared.validateBalanceChange(delta: d)
                    deltaResult = v.allowed ? "allowed: \(v.reason)" : "REJECTED: \(v.reason)"
                }
                if let dr = deltaResult {
                    Text(dr).font(.caption).foregroundColor(dr.hasPrefix("REJECTED") ? .red : .green)
                }
            }
        }
        .navigationTitle("Resource Simulator")
    }
}

struct ResourceSimulatorView_Previews: PreviewProvider {
    static var previews: some View { NavigationView { ResourceSimulatorView() } }
}
