import SwiftUI

/// Security dashboard: shows app integrity + anti-cheat status rows
/// (research [04-anti-cheat-application-security.md](../../04-anti-cheat-application-security.md)).
struct SecurityDashboardView: View {
    @State private var integrity: IntegrityChecker.IntegrityReport?
    @State private var integrityError: Error?
    @State private var lastRefresh = Date()

    private static let features = [
        ("Application integrity", "Code-signing + bundle hash checks", "IntegrityCheckerService"),
        ("Jailbreak detection", "Device risk telemetry", "IntegrityCheckerService"),
        ("Runtime integrity", "Loaded-dylib scan", "IntegrityCheckerService"),
        ("Tamper detection", "Bundle hash re-check", "IntegrityCheckerService"),
        ("API authentication", "Session + mTLS notes", "APISecurityTestView"),
        ("Request validation", "Schema + range checks", "APISecurityTestView"),
        ("Replay prevention", "Nonce + sequence", "APISecurityTestView"),
        ("Anomaly detection", "Z-score scoring", "APISecurityTestView"),
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                Text("SECURITY DASHBOARD").font(.largeTitle).fontWeight(.bold)
                Text("App integrity + anti-cheat status (research per [04](../../04-anti-cheat-application-security.md))")
                    .font(.subheadline).foregroundColor(.secondary)

                IntegrationStatusCard(title: "Device integrity",
                                      subtitle: integrity.map { "\($0.riskLevel) risk (signature: \($0.signatureValid))" } ?? "Not run yet",
                                      lastUpdated: lastRefresh) { }

                Button("Run Integrity Check") {
                    integrity = IntegrityChecker.shared.checkAndReport()
                    lastRefresh = Date()
                }
                .buttonStyle(.borderedProminent)

                Divider()

                Text("Anti-Cheat Features (per [04.10 Summary Table])").font(.title3).bold()
                ForEach(Self.features, id: \.0) { f in
                    HStack {
                        Text(f.0).font(.body).bold()
                        Spacer()
                        Text(f.2).font(.caption).foregroundColor(.secondary)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding()
        }
        .navigationTitle("Security Dashboard")
        .onAppear { integrity = IntegrityChecker.shared.checkAndReport(); lastRefresh = Date() }
    }
}

struct IntegrationStatusCard: View {
    let title: String
    let subtitle: String
    let lastUpdated: Date
    let action: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(title).font(.headline)
                Text(subtitle).font(.caption).foregroundColor(.secondary)
                Text(lastUpdated, style: .relativeDate).font(.caption2).foregroundColor(.secondary)
            }
            Spacer()
            Button("Refresh", action: action).buttonStyle(.borderless)
        }
        .padding()
        .background(Color(UIColor.secondarySystemBackground))
        .cornerRadius(12)
    }
}

struct SecurityDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView { SecurityDashboardView() }
    }
}
