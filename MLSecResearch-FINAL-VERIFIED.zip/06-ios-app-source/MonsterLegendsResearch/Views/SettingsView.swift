import SwiftUI

/// Configurable research settings — persisted via UserDefaults
/// (see [08-test-plan.md](../../08-test-plan.md), feature: Settings and configuration saving).
struct SettingsView: View {
    // AppStorage per key (struct-wrapped AppStorage is not supported by SwiftUI).
    @AppStorage("MLSecResearch.showModMenu") private var showModMenu = true
    @AppStorage("MLSecResearch.telemetryEnabled") private var telemetryEnabled = true
    @AppStorage("MLSecResearch.autoRunOnLaunch") private var autoRunOnLaunch = true
    @AppStorage("MLSecResearch.presetId") private var presetId = SimSettings.presets[0].id

    /// Live view of the settings as a struct (for persistence round-trips).
    var settings: SimSettings {
        SimSettings(id: presetId, showModMenu: showModMenu,
                    telemetryEnabled: telemetryEnabled, autoRunOnLaunch: autoRunOnLaunch)
    }

    var body: some View {
        Form {
            Section("Research Settings") {
                Toggle("Show Mod Menu", isOn: $showModMenu)
                Toggle("Telemetry Enabled", isOn: $telemetryEnabled)
                Toggle("Auto-run tests on launch", isOn: $autoRunOnLaunch)
            }
            Section("Preset") {
                Picker("Preset", selection: $presetId) {
                    ForEach(SimSettings.presets) { Text($0.id).tag($0.id) }
                }
                .onChange(of: presetId) { newId in
                    if let p = SimSettings.presets.first(where: { $0.id == newId }) {
                        showModMenu = p.showModMenu
                        telemetryEnabled = p.telemetryEnabled
                        autoRunOnLaunch = p.autoRunOnLaunch
                    }
                }
            }
            Section("Saved") {
                Text("showModMenu=\(showModMenu) telemetry=\(telemetryEnabled) autoRun=\(autoRunOnLaunch)")
                    .font(.caption).foregroundColor(.secondary)
            }
        }
        .navigationTitle("Settings")
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View { NavigationView { SettingsView() } }
}
