import SwiftUI

/// Test-result history — displays `TestRecord`s with filter.
struct TestHistoryView: View {
    @State private var records: [TestRecord] = TestHistoryStore().all()
    @State private var filter: TestRecord.StatusFilter = .all

    var body: some View {
        VStack {
            Picker("Filter", selection: $filter) {
                ForEach(TestRecord.StatusFilter.allCases, id: \.rawValue) { f in
                    Text(title(for: f)).tag(f)
                }
            }
            .pickerStyle(.segmented)
            .padding()

            Section("Automation") {
                Button("Run Automated Feature Sweep") {
                    for r in TestRunnerService.shared.runFeatureSweep(
                        settings: SettingsView().settings) {
                        TestRunnerService.shared.record(feature: r.feature, name: r.name, status: r.status)
                    }
                    records = TestHistoryStore().all()
                }
                .buttonStyle(.borderedProminent)
                .foregroundColor(Design.neonGreen)
            }

            List {
                ForEach(filtered, id: \.id) { r in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(r.name).font(.body)
                            Text(r.feature).font(.caption).foregroundColor(.secondary)
                        }
                        Spacer()
                        Badge(status: r.status)
                    }
                }
            }
        }
        .navigationTitle("Test History")
        .onAppear { records = TestHistoryStore().all() }
    }

    private var filtered: [TestRecord] {
        switch filter {
        case .all: return records
        case .passed: return records.filter { $0.status == .passed }
        case .failed: return records.filter { $0.status == .failed }
        case .notRun: return records.filter { $0.status == .notRun }
        }
    }

    private func title(for f: TestRecord.StatusFilter) -> String {
        switch f {
        case .all: return "All"
        case .passed: return "Passed"
        case .failed: return "Failed"
        case .notRun: return "Not Run"
        }
    }
}

struct Badge: View {
    let status: TestStatus
    var body: some View {
        Text(status.rawValue.capitalized).font(.caption2)
            .padding(EdgeInsets(top: 2, leading: 8, bottom: 2, trailing: 8))
            .background(status == .passed ? Color.green : status == .failed ? Color.red : Color.gray)
            .cornerRadius(8)
    }
}


struct TestHistoryView_Previews: PreviewProvider {
    static var previews: some View { NavigationView { TestHistoryView() } }
}
