import SwiftUI

/// Timer simulator — cooldowns and stamina recharge
/// (see [01.2.7 Cooldown and timer systems](../../01-game-architecture-investigation.md#127-cooldown-and-timer-systems)).
struct TimerSimulatorView: View {
    @State private var cooldownRemaining: Double = 0
    @State private var elapsedExhausted: Double = 0
    @State private var rechargeChecked = false

    var body: some View {
        List {
            Section("Cooldown") {
                Button("Start Cooldown (12s)") {
                    TimerService.shared.setCooldown(duration: 12)
                    cooldownRemaining = TimerService.shared.cooldownRemaining()
                }
                Text("Remaining: \(cooldownRemaining.formatted(.number.rounded(toIncrement: 0.5)))").font(.body)
            }
            Section("Stamina Recharge (10 min interval)") {
                Button("Start Recharge") {
                    TimerService.shared.startStaminaRecharge(maxStamina: 10)
                    rechargeChecked = false
                }
                Text("Exhausted? \(TimerService.shared.exhausted(maxStamina: 10))")
                Text("Elapsed since exhaust: \(elapsedExhausted.formatted(.number.rounded(toIncrement: 1)))s")
                Button("Advance 5s") { elapsedExhausted = TimerService.shared.elapsedSinceExhausted() }
                Text("Recharged: \(TimerService.shared.rechargedAmount(maxStamina: 10, elapsedSeconds: elapsedExhausted).rounded())")
            }
        }
        .navigationTitle("Timer Simulator")
    }
}

struct TimerSimulatorView_Previews: PreviewProvider {
    static var previews: some View { NavigationView { TimerSimulatorView() } }
}
