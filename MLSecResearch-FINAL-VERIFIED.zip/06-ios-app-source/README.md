# MonsterLegendsResearch — iOS Research Application (SwiftUI)

Modular SwiftUI research app implementing the **FINAL DELIVERABLES** §5 features and the
**FEATURE TESTING** matrix from [08-test-plan.md](../08-test-plan.md) /
[09-final-test-report.md](../09-final-test-report.md).

> Build with: `xcodegen project.yaml && open MonsterLegendsResearch.xcodeproj` on a Mac,
> then `Product > Archive` for the IPA (see [10-installation-instructions.md](../10-installation-instructions.md)).

## Modules

```
MonsterLegendsResearch/
├── Info.plist                                  ← Bundle ID, display name, capabilities
├── MonsterLegendsResearchApp.swift             ← TabView entry, launches TestRunnerService
├── Models/ResearchModels.swift                 ← Element, Monster, Skill, PlayerStats,
│                                                   BattleResult, TestRecord, TestStatus,
│                                                   SimSettings
├── Services/
│   ├── GameEngine.swift                        ← BattleSystemSimulator + DamageCalculator
│   ├── ResourceManagerService.swift            ← ResourceSimulator (client vs server)
│   ├── TimerService.swift                      ← TimerSimulator (cooldown/stamina recharge)
│   ├── IntegrityChecker.swift                  ← Application integrity checks
│   └── TestRunnerService.swift                 ← Automated feature + security tests → TestHistory
├── Views/
│   ├── SecurityDashboardView.swift             ← "Security dashboard" (integrity + anti-cheat rows)
│   ├── BattleSystemSimulatorView.swift         ← Automatic 3-star simulator
│   ├── MonsterDatabaseView.swift               ← Monster database
│   ├── DamageCalculatorView.swift              ← Damage calculator
│   ├── ResourceSimulatorView.swift             ← Resource simulator
│   ├── TimerSimulatorView.swift                ← Timer simulator
│   ├── APISecurityTestView.swift               ← API security test dashboard
│   ├── IntegrityCheckerView.swift              ← Application integrity checker
│   ├── TestHistoryView.swift                   ← Test-result history
│   ├── SettingsView.swift                      ← Configurable research settings (persisted)
│   └── FloatingModMenuView.swift               ← Floating mod-menu overlay (research actions)
└── project.yaml                                ← xcodegen manifest (optional helper)
```

## Feature → view map

| Feature (from report) | View |
|---|---|
| Security dashboard | `SecurityDashboardView.swift` |
| Battle-system simulator | `BattleSystemSimulatorView.swift` |
| Monster database | `MonsterDatabaseView.swift` |
| Damage calculator | `DamageCalculatorView.swift` |
| Resource simulator | `ResourceSimulatorView.swift` |
| Timer simulator | `TimerSimulatorView.swift` |
| API security test dashboard | `APISecurityTestView.swift` |
| Application integrity checker | `IntegrityCheckerView.swift` |
| Test-result history | `TestHistoryView.swift` |
| Settings and configuration saving | `SettingsView.swift` |
| Floating mod menu | `FloatingModMenuView.swift` |
