# 7. Test Environment Instructions

> **Status:** required to run device tests; not verifiable in this Linux environment
> (see [README](README.md) "IMPORTANT"). Follow these on a Mac with Xcode.

## 7.1 Host prerequisites

- macOS with Xcode 14+ installed.
- Apple Developer Program account (see [10-installation-instructions.md](10-installation-instructions.md)).
- iPhone (iOS 15+) or simulator for QA.

## 7.2 Building & running on simulator

```bash
cd /home/user/MLSecResearch/06-ios-app-source
xcodegen project.yaml        # generate MonsterLegendsResearch.xcodeproj
open MonsterLegendsResearch.xcodeproj
# In Xcode: Product > Build, then Run on the iPhone simulator
```

## 7.3 Building the IPA (device testing)

```bash
open MonsterLegendsResearch.xcodeproj
# Product > Archive
# Xcode Organizer → Export ▸ Development or Ad Hoc ▸ Export
# Result: MonsterLegendsResearch.ipa
```

## 7.4 Install with KSign

1. Transfer the IPA to the iPhone (AirDrop, or Files on the phone).
2. Open KSign (installed per [10.2](10-installation-instructions.md)), import the IPA.
3. Tap **Sign** with your certificate + matching provisioning profile, then install.
4. Trust the enterprise certificate in **Settings > General > VPN & Device Management**.
5. Launch the app, verify the integration is performed (callout by language file).

## 7.5 Webhook test server (optional for replay/auth tests)

Run a controlled backend stub (per [08-test-plan.md](08-test-plan.md)) at `localhost:7350`
with a TLS CA; tests in `APISecurityTestView` hit it when `TestEnvironmentSettings` allows.
