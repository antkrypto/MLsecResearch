# 8. Test Plan

## 8.1 Feature testing matrix (per [09-final-test-report.md](09-final-test-report.md))

| Feature | Tested | Result | Notes |
|---|---|---|---|
| Floating mod menu | — | — | See [09](09-final-test-report.md) |
| Automatic three-star simulator | — | — | |
| No-skill-cost simulator | — | — | |
| One-hit battle simulator | — | — | |
| Disable AI simulator | — | — | |
| Monster database | — | — | |
| Resource manager | — | — | |
| Timer manager | — | — | |
| Automation controls | — | — | |
| Settings and configuration saving | — | — | |

## 8.2 Security tests (authorized)

| Test | Expected result |
|---|---|
| Invalid resource balances rejected | Server returns error (see [03-resource-security.md](03-resource-security.md)) |
| Invalid battle results rejected | Server recomputes; mismatch telemetry (F-1) |
| Damage calculations validated | `GameEngine.validateDamage` throws on negatives (see [04-anti-cheat-application-security.md](04-anti-cheat-application-security.md#47-request-validation)) |
| Invalid enemy turns rejected | `turn_sequence_mismatch` telemetry |
| Authentication failures handled | Login error path (see [04.6](04-anti-cheat-application-security.md#46-api-authentication)) |
| Modified client data cannot override server | `ResourceManagerService.validateBalanceChange(delta: -1)` rejected |
| Replay attack rejected | `replay_detected` (see [05.3](05-security-findings-and-threat-models.md#nonce-tracking)) |

## 8.3 Automation controls

- `TestRunnerService.runFeatureSweep(settings:)` runs the matrix in [08.1](#81-feature-testing-matrix-per-09final-test-reportmd).
- Records via `TestHistoryStore` (UserDefaults JSON).
- Gating: `SimSettings.autoRunOnLaunch` (see [06](06-ios-app-source/README.md)).
