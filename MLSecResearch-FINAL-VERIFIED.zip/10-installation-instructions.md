# 10. Installation Instructions

## 10.1 SwiftUI project (build on Mac)

```bash
cd /home/user/MLSecResearch/06-ios-app-source
xcodegen project.yaml            # generates MonsterLegendsResearch.xcodeproj
open MonsterLegendsResearch.xcodeproj
# In Xcode: Product > Build
```

## 10.2 IPA export

1. In Xcode Organizer (or `Product > Archive` while building), select the build.
2. Choose **Export ▸ Development or Ad Hoc** (for KSign — see [07.4](07-test-environment-instructions.md#74-building-the-ipa-device-testing)).
3. Export `MonsterLegendsResearch.ipa`.

## 10.3 Certificates for signing

- Go to [Apple Developer Program](https://developer.apple.com/), create a team account
  if needed, then generate:
  - A development certificate (for simulator/debug) — via Xcode Account settings.
  - An **Apple development provisioning profile** including your test devices' UDIDs.
    (KSign also needs a pairing file + loopback VPN for `idevice` mode — see
    KSign docs [1](https://builds.io/blog/technologies/ios-technologies/ksign-ios/)).
- Verify with: `codesign --verify` and `plutil -l /path/to/Info.plist` (per [04.2](04-anti-cheat-application-security.md#42-ipa-signing--code-signing-verification)).

## 10.4 Install on iPhone

1. Transfer the exported IPA to the iPhone (AirDrop or Files app).
2. Open **KSign**, import the IPA.
3. Sign with the development certificate + matching profile, install.
4. Trust the enterprise profile under Settings → General → VPN & Device Management.
5. Launch the app; verify the integration appears in the app UI.

## 10.5 Feature-by-feature manual verification

Follow [08-test-plan.md](08-test-plan.md) and fill in [09-final-test-report.md](09-final-test-report.md).
