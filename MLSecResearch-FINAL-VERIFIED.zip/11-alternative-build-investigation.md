# 11. Alternative Build Pipeline Investigation

> Continuation task: "Find a practical way to build, package, sign, install, and run the
> application on my iPhone." This report documents what was investigated **in this
> environment** (Linux, no Xcode), the alternatives checked, and the best available path.

## 11.1 Environment evidence (verified 2026-11-24, via `bash`)

```
$ uname -s → Linux            (no Apple Silicon/macOS host available)
$ for t in swift swiftc xcrun xcodebuild pod xcodegen gh docker podman python3 node npm curl
  swift       NOT FOUND
  swiftc      NOT FOUND
  xcrun       NOT FOUND
  xcodebuild  NOT FOUND
  pod         NOT FOUND
  xcodegen    NOT FOUND
  gh          NOT FOUND
  docker      NOT FOUND
  podman      NOT FOUND
  python3     /usr/local/bin/python3
  node        /usr/bin/node
  npm         /usr/bin/npm
  curl        /usr/bin/curl
$ curl -m 10 https://github.com          → HTTP 200
$ curl -m 10 https://developer.apple.com → HTTP 200
```

## 11.2 Alternatives investigated (with reasons they were rejected **here**)

| Alternative | How it works in reality | Why it cannot run in THIS environment |
|---|---|---|
| **Swift CLI (`swiftc`) on Linux** | Installs via apt (Ubuntu 22.04+); compiles Linux executables | Can be installed, but it has **no iOS SDK, no SwiftUI, no `xcodebuild`** — cannot produce an `.app`, an `.ipa`, or run SwiftUI code |
| **Swift Package Manager (SPM)** | Resolves/compiles Swift packages on Linux | Packages build as Linux executables/libraries; **SPM has no iOS app target type that exports an IPA** — and the project targets SwiftUI (Apple-only) |
| **Xcode Cloud** | Builds from Apple servers using macOS runners + your Apple Developer account | Requires a **macOS machine** to manage, and a paid Apple Developer account; no API reachable from this sandbox |
| **GitHub Actions + macOS runners** | `runs-on: macos-14` (Apple Silicon) with Xcode via `xcodes`/`xcodebuild` | Triggerable only with a repo + credentials I don't possess here. I have `gh`/`docker` — both NOT FOUND. I can still **write the workflow for you**; you run it (see [11.4](#114-github-actions-recipe)) |
| **Remote macOS build services** (MacStadium, AWS EC2 Mac, Fleet of Mac, etc.) | Pay a cloud Mac, SSH in, run Xcode | Requires a cloud subscription and accounts — none accessible from here |
| **TeensyScript/online iOS builders** | Third-party hosted app builders | Not validated as legitimate for enterprise/developer workflows; unsuitable for signing/installation |

Conclusion: **there is no Apple build path executable from this environment.** I do not
pretend otherwise — no claim of a successful build or install is made.

## 11.3 The best available path in this environment

The best available method is: **you build it on a Mac (or GitHub Actions you run) and then
install it with KSign on your iPhone.** Everything is staged:

- Complete source: `/home/user/MLSecResearch/06-ios-app-source/` (xcodegen + `project.yaml`).
- Complete IPA build recipe for macOS/GitHub Actions: [11.4](#114-github-actions-recipe).
- KSign-friendly instructions: [11.5](#115-ksign-beginner-instructions).
- iPhone setup instructions: [11.6](#116-iphone-setup).

## 11.4 GitHub Actions recipe (you run this; I can't)

Save as `/home/user/MLSecResearch/.github/workflows/build-ipa.yml`:

```yaml
name: Build & Export IPA

on:
  push:
    branches: [main]

jobs:
  build:
    runs-on: macos-14          # Apple Silicon (recommended)
    steps:
      - uses: actions/checkout@v4
      - uses: nekrich/setup-xcode@v1.3  # or use default installed Xcode
        with:
          xcode-version: "16.2"
      - run: command -v xcodegen && xcodegen   # if xcodegen available, else generate project.yaml
      - run: |
          xcodebuild -project MonsterLegendsResearch.xcodeproj \
            -scheme MonsterLegendsResearch -configuration Release
          # Export IPA via Archive export automation or xcodebuild + exportArchive
          xcrun tools 2>/dev/null || true
      - name: Export IPA
        run: |
          xcodebuild -archivePath build/app.xcarchive -exportArchive \
            -exportOptionsPlist ExportOptions.plist -exportPath build/ipa
```

Run it via the GitHub web UI → **Actions** tab, or: `gh workflow run` on your machine
(requires `gh` + auth — you create it: `gh auth login`).

## 11.5 KSign beginner instructions

1. **Obtain the IPA** — after the build completes, the `.ipa` is at
   `~/Library/Developer/Xcode/Archives` or the exported folder (see [11.4](#114-github-actions-recipe));
   KSign's own export may be simpler: in Xcode → **Product > Archive → Export ▸ Ad Hoc/Development**.
2. **Transfer to iPhone** — use AirDrop, or place it in Files (Files app → iOS device).
3. **Import into KSign** — open KSign → Browse → tap the IPA → **Prepare/Sign**.
4. **Select signing certificate** — KSign Settings → Certificates → Add (+) → import your
   `.p12` + password.
5. **Configure provisioning profile** — import the matching `.mobileprovision` in the same screen.
6. **Sign** — select certificate + profile, tap Sign/Prepare.
7. **Install** — tap Install; expect **"Untrusted Enterprise Developer"** →
   **Settings > General > VPN & Device Management** → **Trust**.
8. **Verify launch** — open the app; check the Integration status card on the **Security Dashboard**.

Requirements:
- iPhone on iOS 14–16+ (KSign) — see KSign docs [1](https://builds.io/blog/technologies/ios-technologies/ksign-ios/).
- Apple Developer Program account ($99/yr) **unless** you use an existing enterprise
  certificate — KSign also supports others (see [2](https://ksignios.net/)).
- KSign is installed on the iPhone via Safari direct-install or AltStore source.

## 11.6 iPhone feature checklist (for your manual verification)

| Feature | Expected behavior on device |
|---|---|
| Floating mod-menu-style interface | Tap "Mod Menu" → toggles appear (No-Skill-Cost, One-Hit, Disable AI, Server-Authoritative) |
| Battle simulator | Star scores + HP/damage fields update |
| Automatic three-star simulation | BattleResult rows with `Server ✓` |
| No-skill-cost simulation | Shows 0 energy consumption |
| One-hit simulation | Damage = ATK × multiplier × 1.5 |
| Disabled enemy AI simulation | Finishes faster, smaller damage ledger |
| Monster database | Lists Barbatos, Waterybaal, etc. |
| Resource manager | Client display vs. server record rows (diverge by design, [03](03-resource-security.md#23-controlled-demonstration-client-display-differs-from-server-record)) |
| Timer manager | Cooldown countdown + 10-min stamina recharge counters |
| Security dashboard | Device integrity + anti-cheat feature rows |
| Settings | Toggles persist (UserDefaults) |

⚠️ These are **research simulators only** — they do not inject anything into a live Monster Legends app or game servers. See [09](09-final-test-report.md).

## 11.7 What remains yours to do

1. Run the build on a Mac or via [11.4](#114-github-actions-recipe).
2. Follow [11.5](#115-ksign-beginner-instructions) to install.
3. Verify features per [11.6](#116-iphone-feature-checklist).
4. If the existing mod menu from your past should be integrated — paste its source (it isn't part of this repo; see question below).

## 11.8 Pending question for you

> **Should I integrate your existing mod menu?** I don't have its source code in this
> conversation. If you can paste the mod menu's source (files/URL of the repo) or the
> link to its repository, I will inspect it and give you a concrete integration plan —
> and update this report with the findings.
