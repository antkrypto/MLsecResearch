# 12. Build the IPA & Install on Your iPhone (KSign)

> Status: run this on a Mac (see [11-alternative-build-investigation.md](11-alternative-build-investigation.md)
> — Linux cannot build; the workflow is described in §3.4 of that document).

## 0. Build the IPA first

1. `cd /home/user/MLSecResearch/06-ios-app-source`
2. `xcodegen project.yaml` → `MonsterLegendsResearch.xcodeproj`
3. `open MonsterLegendsResearch.xcodeproj`
4. In Xcode: **Product > Build**, then **Product > Archive** (may need a Release scheme — select `MonsterLegendsResearch`).
5. In the Organizer: **Export ▸ Development or Ad Hoc** → save as `MonsterLegendsResearch.ipa`.

(Alternatives: GitHub Actions — `.github/workflows/build-ipa.yml`, [11.4](11-alternative-build-investigation.md#114-github-actions-recipe).)

## 1. Download the IPA

- AirDrop from the Mac to your iPhone, or
- Files app on the iPhone (transferred via AirDrop), or
- From the GitHub Actions artifact page (§3 of the workflow doc), or
- From the Organizer "Reveal in Finder" — save to a memorable folder, e.g. `~/Downloads`.

## 2. Open KSign

- KSign is installed on your iPhone via: Safari direct-install, AltStore source, or by importing KSign.ipa (see KSign docs [1](https://builds.io/blog/technologies/ios-technologies/ksign-ios/)).

## 3. Import the IPA into KSign

- Tap **Import** / **Add IPA** → browse to `MonsterLegendsResearch.ipa` → **Prepare/Import**.

## 4. Select signing certificate

- KSign Settings → Certificates → **+** → import `MLSecResearch.p12` (+ password) — or generate a free personal dev certificate via Xcode's Accounts (see [11.5](11-alternative-build-investigation.md#115-ksign-beginner-instructions)).
- Choose the certificate for the app.

## 5. Configure the provisioning profile

- In the same Certificates screen, import the matching `MLSecResearch.mobileprovision`.
- KSign generates/overrides profiles on-device if none provided (per KSign docs [2](https://ksignios.net/)).

## 6. Sign

- Tap **Sign/Prepare** on the imported app → select the certificate + profile if prompted → confirm.

## 7. Install

- Tap **Install** → **Trust** if you see "Untrusted Enterprise Developer".

## 8. Verify launch

- Open the app → check the **Security Dashboard** shows "Not Run yet" + integrity rows; tap the tabs to verify all 11 features render.

## 9. Requirements summary

| Item | Needed? |
|---|---|
| iPhone | iOS 14–16+ |
| Apple Developer Program | $99/yr — unless you use an existing enterprise certificate |
| KSign | Installed on device |
| .p12 + password | Yes — dev cert or enterprise cert |
| .mobileprovision (matching bundle ID) | Yes — KSign may generate it; preferred to import yours |
| Offline play testing | Works for standalone research features |

See full build/install flow: [11-alternative-build-investigation.md](11-alternative-build-investigation.md#115-ksign-beginner-instructions).
