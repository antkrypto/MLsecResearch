# Build-Readiness Code Review Report

> Review date: 2026-11-24 — status of every file in [06-ios-app-source/](06-ios-app-source/)
> for compilation readiness, functionality, and feature completeness.

## 1. Review methodology

Manual code review (Linux host has no Swift toolchain — verified; [11-alternative-build-investigation.md](11-alternative-build-investigation.md#11-environment-evidence)):

- All 19 Swift files read and reviewed.
- Symbol scan + crude brace/paren balance check per file (passed).
- Fixes applied per category below.

## 2. Findings and fixes

| ID | Category | File | Issue | Fix applied |
|----|----------|------|-------|-------------|
| R1 | Compilation | `FloatingModMenuView.swift` | `.onChange(of:)` usage is version-sensitive | Rewritten without onChange; uses `MenuItem`-style static list + buttons |
| R2 | Compilation | `FloatingModMenuView.swift` | Custom extension naming | `triggerStyle()` — safe, documented |
| R3 | Compilation | `SettingsView.swift` | `@AppStorage` on struct | Replaced with per-key AppStorage (Bool/String); `settings` view property |
| R4 | Compilation | `TestHistoryView.swift` | Picker tag/selection mismatch; `PickerOption` | Fixed with `Text(title(for: f)).tag(f)`; removed unused type |
| R5 | Compilation | `BattleSystemSimulatorView.swift`, `DamageCalculatorView.swift` | Picker selections without tags | Fixed with `Text(...).tag(...)` |
| R6 | Compilation | `IntegrityChecker.swift` | Awkward `Data.reduce` hash | Rewritten with `Insecure.MD5` (CryptoKit) |
| R7 | Compilation | `MonsterLegendsResearchApp.swift` | `.sheet(item: $testResults.first)` invalid | Fixed with `@State private var historySheet: TestRecord?` |
| R8 | Functionality | `TestRunnerService.swift` | Hardcoded `.passed` sweep results ("test the feature by asserting it passed") | Real checks via new `FeatureChecks.swift`; sweep records real outcomes |
| R9 | Functionality | `FeatureChecks.swift` (new) | — | New module with executable assertions per feature |

## 3. Feature coverage (all 11 features — see [12](12-build-on-iphone.md#9-requirements-summary))

| Feature | File | Notes |
|---|---|---|
| Floating mod menu | `Views/FloatingModMenuView.swift` (overlay in App) | Shows menu items; toggles visible |
| Automatic three-star simulator | `Views/BattleSystemSimulatorView.swift` + `GameEngine.simulateBattle` | ServerComputed = true |
| No-skill-cost simulator | `GameEngine.simulateNoSkillCostBattle` + `Views/BattleSystemSimulatorView.swift`? — main entry: `Views/BattleSystemSimulatorView.swift`? Actually via `FloatingModMenu` + `GameEngine` | damage > 0 |
| One-hit simulator | `GameEngine.simulateBattle(mode: "oneHit")` | hpRemaining == 0 |
| Disabled AI simulator | `GameEngine.simulateBattle(mode: "disabledAI")` | damage > 0, serverComputed |
| Monster database | `Views/MonsterDatabaseView.swift` | samples non-empty |
| Damage calculator | `Views/DamageCalculatorView.swift` | positive damage + validateDamage passes |
| Resource simulator | `Views/ResourceSimulatorView.swift` + `ResourceManagerService` | client ≠ server (demo divergence) |
| Timer simulator | `Views/TimerSimulatorView.swift` + `TimerService` | cooldownRemaining > 0 |
| Security dashboard | `Views/SecurityDashboardView.swift` | integrity + anti-cheat rows |
| Settings | `Views/SettingsView.swift` | AppStorage round-trip |

## 4. Non-claims

- No feature is presented as injecting anything into a live Monster Legends app — all simulators are standalone
  (see [09](09-final-test-report.md)).
- Build logs (`build-compile.log`, `build-archive.log`, `build-export.log`) are produced by the GitHub Actions workflow
  when run on a Mac (`--upload` artifacts); recorded in `TEST_RESULTS.md` when executed.
