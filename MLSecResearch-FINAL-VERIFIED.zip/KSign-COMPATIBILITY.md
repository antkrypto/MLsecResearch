# KSign Compatibility Check (IPA — Pre-Installation)

> **Honesty note:** the IPA is generated only on a Mac (see [11-alternative-build-investigation.md](11-alternative-build-investigation.md)). This document describes the compatibility criteria and the check steps to run before importing into KSign. Mark each row ✅/⚠️/❌ after you run the step.

## Bundle structure (check on Mac after export)

| Item | Expected |
|---|---|
| `MonsterLegendsResearch.app/Info.plist` | present |
| `MonsterLegendsResearch` executable ( Mach-O arm64/x86_64) | present |
| `Frameworks/`, `PlugIns/` | optional (absent is OK for this app) |
| No `.dylib`/`PlugIns` | must be absent unless explicitly added |

## Bundle ID / version

| Field | Expected |
|---|---|
| CFBundleIdentifier | `com.arena.mlsecresearch` (matches `06-ios-app-source/MonsterLegendsResearch/Info.plist` + `project.yaml`) |
| CFBundleShortVersionString | `1.0` |
| CFBundleVersion | `1` |

## Minimum iOS version

| Field | Expected |
|---|---|
| MinimumOSVersion | `16.0` (see `06-ios-app-source/project.yaml` — `deploymentTarget: "16.0"`) |

## Signing & profile compatibility

| Item | Requirement |
|---|---|
| Certificate | Apple Developer (iOS App Development) or enterprise cert; must be a *development* cert for on-device install |
| Provisioning profile | App ID `com.arena.mlsecresearch`, Apple Services: none required, includes the device UDID |
| Entitlements | none expected (research app: no iCloud, no bg modes) |
| Validation | `codesign -dvv` shows your team; `otool -l` shows `LC_ENCRYPTION_INFO_64`; `plutil -l Info.plist` OK |

## Device registration

- On iPhone: Settings → General → VPN & Device Management → **Trust** your certificate
  after installation (KSign warning expected).

## KSign import steps (exact order — see [12-build-on-iPhone.md](12-build-on-iPhone.md))

1. Transfer the exported `MonsterLegendsResearch.ipa` to the iPhone (AirDrop).
2. Open KSign → import the IPA.
3. Select certificate (import `MLSecResearch.p12`).
4. Select/import matching provisioning profile.
5. Sign → Install → Trust.
6. Launch → verify tabs render (Battle Simulator, Monster DB, Damage, Resources, Timers,
   Security, Integrity, API Security, History, Settings + Floating Mod Menu overlay).

Update rows to ✅ when verified on device.
