# Test Results

> Recorded per [08-test-plan.md](08-test-plan.md) and [09-final-test-report.md](09-final-test-report.md).
> **Honesty note:** this environment (Linux, no Xcode, no Swift toolchain) cannot run iOS
> builds or install on devices. Device-side results are marked **Not Run** rather than faked.
> Code-level checks were performed via manual review ([BUILD_READINESS_REVIEW.md](BUILD_READINESS_REVIEW.md)).

## A. Feature sweep (real checks via `FeatureChecks.swift`)

| # | Feature | Check executed | Expected result | Status |
|---|---------|----------------|-----------------|--------|
| 1 | Floating mod menu | `FeatureChecks.checkFloatingModMenu()` — `FloatingModMenuView.menuItems.count > 0` | Pass | ⏳ (macOS only) |
| 2 | Automatic three-star simulator | `GameEngine.simulateBattle` → `serverComputed && stars in 0...3` | Pass | ⏳ |
| 3 | No-skill-cost simulator | `simulateNoSkillCostBattle` → `damageDealt > 0` | Pass | ⏳ |
| 4 | One-hit simulator | `simulateBattle(mode:"oneHit")` → `hpRemaining == 0` | Pass | ⏳ |
| 5 | Disabled AI simulator | `simulateBattle(mode:"disabledAI")` → `damageDealt > 0 && serverComputed` | Pass | ⏳ |
| 6 | Monster database | `Monster.samples.isEmpty == false` | Pass | ⏳ |
| 7 | Damage calculator | `damage > 0 && validateDamage(d) throws == nil` | Pass | ⏳ |
| 8 | Resource manager | `validateBalanceChange(delta: -1).allowed == false` && `demonstrationSnapshot().client != server` | Pass | ⏳ |
| 9 | Timer manager | `cooldownRemaining() > 0 && isCoolingDown()` | Pass | ⏳ |
| 10 | Automation controls | sweep runs (self) | Pass | ⏳ |
| 11 | Settings persistence | UserDefaults round-trip (`"ok"`) | Pass | ⏳ |

## B. Security sweep (real validator behavior, `runSecuritySweep`)

| Test | Validator | Expected | Status |
|---|---|---|---|
| Invalid resource changes rejected | `ResourceManagerService.validateBalanceChange(delta: -1).allowed` | false | ⏳ |
| Invalid battle results rejected | `GameEngine.validateStars(value: 4)` throws | true | ⏳ |
| Damage calculations validated | `GameEngine.validateDamage(value: -1)` throws | true | ⏳ |
| Modified client data cannot override server | `validateBalanceChange(delta: -1).allowed` == false | Pass | ⏳ |

## C. Build logs

Generated when run on macOS:

- `build-compile.log` — `xcodebuild build` output
- `build-archive.log` — `xcodebuild archive` output
- `build-export.log` — `xcodebuild -exportArchive` output

Run them from the workflow: `gh run download` or copy from GitHub Actions artifacts.

## D. Environment distinction

| Level | Verdict |
|---|---|
| Linux sandbox (this env) | Source review + symbol/balance checks only |
| macOS build | Not yet run (needs Mac) |
| Simulator run | Not yet run |
| Physical iPhone install | Not yet run — see [12](12-build-on-iphone.md) |

Update the ⏳ rows after running tests in [12](12-build-on-iphone.md) and [09-final-test-report.md](09-final-test-report.md).
