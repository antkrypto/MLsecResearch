# How to Upload This Project to GitHub (all on iPhone, no computer)

Goal: get the `MLSecResearch-FINAL-VERIFIED.zip` into a GitHub repo so you can run the macOS build workflow from your phone via Safari/the GitHub app.

## What you need

- iPhone + Safari (or the GitHub app from the App Store — faster and better uploads).
- A free GitHub account.
- No Apple credentials (for **Workflow A — unsigned**).

## Step 1 — Create the repo on iPhone

1. Open https://github.com/new in Safari.
2. Choose a repo name (e.g. `MLSecResearch`), set it to **Public or Private**, then tap **Create repository**.

## Step 2 — Upload the project files

You need `MLSecResearch-FINAL-VERIFIED.zip` in Files app. (It should be in your Downloads/AirDrop.)

Via the **GitHub app** (recommended):
1. Open the GitHub app → **+ → New repository**, or open your repo → tap **"+" (Add file) → Upload files**.
2. Use the iPhone share sheet → select the `.zip` from Files app.
3. Name it `MLSecResearch-FINAL-VERIFIED.zip` → tap **Commit**.

Via **Safari** (fallback):
1. On the repo page tap **"Add file" → "Upload files"**.
2. Tap **Choose Files** (Files app) → pick the `.zip`.
3. Tap **Commit**.

Alternatively (more reliable): upload the *extracted* folder — GitHub web lets you drag files, but on-device it's usually easiest to zip it first, as above.

## Step 3 — Verify the repo contents

Open https://github.com/<you>/MLSecResearch/tree/main in Safari — you should see `MLSecResearch-FINAL-VERIFIED.zip` and the `06-ios-app-source/` folder.

## Step 4 — Run Workflow A (build unsigned IPA) from your phone

1. Open https://github.com/<you>/MLSecResearch/actions in Safari.
2. Tap **"Workflow A — Build & Test (no distribution signing)"** in the list → tap **"Run workflow"** (green button) → then tap **"Run workflow"** again.
3. The workflow runs on GitHub's macOS runners — your iPhone is only watching. When done, the list shows a green check.

## Step 5 — Download the IPA artifact to your iPhone

1. Open https://github.com/<you>/MLSecResearch/actions again.
2. Tap the latest run of Workflow A → under **"Artifacts"** tap **`MLSecResearch-A-unsigned`** (or `MLSecResearch-B-signed`).
3. The artifact downloads as a **.zip** — Safari saves it to your Files app/Downloads.
4. Unzip it on your phone (or transfer to your computer later if needed).

The artifact contains the `.ipa` (for B) plus build logs — see `build-compile.log`, `build-archive.log`, `build-export-signed.log`.

## Step 6 — KSign (on iPhone)

Follow [12-build-on-iPhone.md](12-build-on-iPhone.md): open KSign → import the IPA → select certificate → sign → install → trust.

## Step 7 (optional) — Workflow B (signed IPA)

If you want a properly signed IPA, add repository secrets (Settings → Secrets and variables → Repository secrets):

| Secret | Content |
|---|---|
| `CERT_P12_BASE64` | Base64 of your `.p12` |
| `CERT_P12_PASSWORD` | Password of the `.p12` |
| `APPLE_TEAM_ID` | Your Apple Developer Program Team ID (e.g. `ABC123DE45`) |
| `PROVISIONING_PROFILE` | Base64 of the matching `.mobileprovision` |

Then run **Workflow B — Build & Export Signed IPA** in the Actions tab.

## Notes

- The IPA is **not on your iPhone** until you download the artifact in Step 5.
- iOS runners on GitHub are free for public repos; for signed exports you still need the Apple Developer account ($99/yr) or an existing enterprise certificate.
- Estimated build time: 3–8 minutes.
